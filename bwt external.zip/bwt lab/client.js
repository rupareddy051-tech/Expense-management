import React, { useState, useEffect } from 'react';

const API_BASE = '/api';

export default function App() {
  const [token, setToken] = useState(localStorage.getItem('token') || '');
  const [user, setUser] = useState(null);
  const [expenses, setExpenses] = useState([]);
  const [categories, setCategories] = useState([]);
  const [stats, setStats] = useState(null);

  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [category, setCategory] = useState('Food');
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [search, setSearch] = useState('');
  const [filterCategory, setFilterCategory] = useState('All');

  const [email, setEmail] = useState('admin@example.com');
  const [password, setPassword] = useState('admin123');
  const [isRegister, setIsRegister] = useState(false);
  const [name, setName] = useState('');
  const [error, setError] = useState('');

  const getHeaders = () => ({
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  });

  const handleAuth = async (e) => {
    e.preventDefault();
    setError('');
    const endpoint = isRegister ? '/auth/register' : '/auth/login';
    const payload = isRegister ? { name, email, password } : { email, password };

    try {
      const res = await fetch(`${API_BASE}${endpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Auth failed');

      localStorage.setItem('token', data.token);
      setToken(data.token);
      setUser(data.user);
    } catch (err) {
      setError(err.message);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setToken('');
    setUser(null);
    setExpenses([]);
    setStats(null);
  };

  useEffect(() => {
    if (!token) return;
    fetch(`${API_BASE}/auth/me`, { headers: getHeaders() })
      .then((res) => (res.ok ? res.json() : Promise.reject('Invalid token')))
      .then((data) => setUser(data))
      .catch(() => handleLogout());
  }, [token]);

  useEffect(() => {
    fetch(`${API_BASE}/categories`)
      .then((res) => res.json())
      .then((cats) => {
        setCategories(cats);
        if (cats.length > 0) setCategory(cats[0]);
      })
      .catch(console.error);
  }, []);

  const loadData = () => {
    if (!token) return;
    const params = new URLSearchParams();
    if (filterCategory !== 'All') params.set('category', filterCategory);
    if (search) params.set('search', search);

    fetch(`${API_BASE}/expenses?${params.toString()}`, { headers: getHeaders() })
      .then((res) => res.json())
      .then((data) => setExpenses(Array.isArray(data) ? data : []))
      .catch(console.error);

    fetch(`${API_BASE}/expenses/stats`, { headers: getHeaders() })
      .then((res) => res.json())
      .then((data) => setStats(data))
      .catch(console.error);
  };

  useEffect(() => {
    loadData();
  }, [token, filterCategory, search]);

  const handleAddExpense = async (e) => {
    e.preventDefault();
    if (!amount || Number(amount) <= 0) return alert('Enter a valid amount');

    try {
      const res = await fetch(`${API_BASE}/expenses`, {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({
          date,
          category,
          amount: parseFloat(amount),
          description,
        }),
      });
      if (!res.ok) throw new Error('Failed to create expense');

      setAmount('');
      setDescription('');
      loadData();
    } catch (err) {
      alert(err.message);
    }
  };

  const handleDeleteExpense = async (id) => {
    if (!window.confirm('Delete this expense?')) return;
    try {
      const res = await fetch(`${API_BASE}/expenses/${id}`, {
        method: 'DELETE',
        headers: getHeaders(),
      });
      if (res.ok) loadData();
    } catch (err) {
      alert(err.message);
    }
  };

  if (!token || !user) {
    return (
      <div style={{ maxWidth: 400, margin: '60px auto', fontFamily: 'sans-serif' }}>
        <h2>{isRegister ? 'Register' : 'Login'} - Expense Tracker</h2>
        {error && <div style={{ color: 'red', marginBottom: 12 }}>{error}</div>}
        <form onSubmit={handleAuth}>
          {isRegister && (
            <div style={{ marginBottom: 10 }}>
              <label>Name:</label>
              <input
                style={{ width: '100%', padding: 8 }}
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>
          )}
          <div style={{ marginBottom: 10 }}>
            <label>Email:</label>
            <input
              style={{ width: '100%', padding: 8 }}
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div style={{ marginBottom: 14 }}>
            <label>Password:</label>
            <input
              style={{ width: '100%', padding: 8 }}
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <button style={{ width: '100%', padding: 10, background: '#4f46e5', color: '#fff' }}>
            {isRegister ? 'Register' : 'Sign In'}
          </button>
        </form>
        <button
          onClick={() => setIsRegister(!isRegister)}
          style={{ marginTop: 12, background: 'none', border: 'none', color: '#4f46e5', cursor: 'pointer' }}
        >
          {isRegister ? 'Already have an account? Login' : 'Need an account? Register'}
        </button>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 900, margin: '20px auto', fontFamily: 'sans-serif', padding: 16 }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1>Expense Management (MERN)</h1>
        <div>
          <span>{user.name} ({user.role})</span>
          <button onClick={handleLogout} style={{ marginLeft: 12, padding: '6px 12px' }}>
            Logout
          </button>
        </div>
      </header>

      {stats && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, margin: '20px 0' }}>
          <div style={{ padding: 14, border: '1px solid #ddd', borderRadius: 8 }}>
            <small>Total Spent</small>
            <h3>₹{stats.totalSpent?.toLocaleString('en-IN')}</h3>
          </div>
          <div style={{ padding: 14, border: '1px solid #ddd', borderRadius: 8 }}>
            <small>This Month</small>
            <h3>₹{stats.thisMonthSpent?.toLocaleString('en-IN')}</h3>
          </div>
          <div style={{ padding: 14, border: '1px solid #ddd', borderRadius: 8 }}>
            <small>Total Records</small>
            <h3>{stats.transactionCount}</h3>
          </div>
        </div>
      )}

      <form onSubmit={handleAddExpense} style={{ display: 'flex', gap: 8, margin: '20px 0' }}>
        <input type="date" value={date} onChange={(e) => setDate(e.target.value)} required />
        <select value={category} onChange={(e) => setCategory(e.target.value)}>
          {categories.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
        <input
          type="number"
          placeholder="Amount (₹)"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          required
        />
        <input
          type="text"
          placeholder="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          style={{ flex: 1 }}
        />
        <button type="submit" style={{ padding: '8px 16px', background: '#4f46e5', color: '#fff' }}>
          Add
        </button>
      </form>

      <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
        <input
          type="text"
          placeholder="Search..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{ flex: 1, padding: 6 }}
        />
        <select value={filterCategory} onChange={(e) => setFilterCategory(e.target.value)}>
          <option value="All">All Categories</option>
          {categories.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
      </div>

      <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
        <thead>
          <tr style={{ background: '#f3f4f6' }}>
            <th style={{ padding: 8 }}>Date</th>
            <th style={{ padding: 8 }}>Category</th>
            <th style={{ padding: 8 }}>Description</th>
            <th style={{ padding: 8, textAlign: 'right' }}>Amount</th>
            <th style={{ padding: 8, textAlign: 'right' }}>Action</th>
          </tr>
        </thead>
        <tbody>
          {expenses.map((item) => (
            <tr key={item._id} style={{ borderBottom: '1px solid #eee' }}>
              <td style={{ padding: 8 }}>{item.date}</td>
              <td style={{ padding: 8 }}>{item.category}</td>
              <td style={{ padding: 8 }}>{item.description || '-'}</td>
              <td style={{ padding: 8, textAlign: 'right' }}>₹{item.amount?.toLocaleString('en-IN')}</td>
              <td style={{ padding: 8, textAlign: 'right' }}>
                <button
                  onClick={() => handleDeleteExpense(item._id)}
                  style={{ color: 'red', border: 'none', background: 'none', cursor: 'pointer' }}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}