const express = require('express');
const router = express.Router();
const Expense = require('../models/Expense');
const { CATEGORIES } = require('../models/Expense');
const { auth } = require('../middleware/auth');

function validateExpenseInput(body) {
  if (!body.date || isNaN(new Date(body.date).getTime())) {
    return 'Valid date in format YYYY-MM-DD is required';
  }
  if (!CATEGORIES.includes(body.category)) {
    return `Invalid category. Must be one of: ${CATEGORIES.join(', ')}`;
  }
  const amt = Number(body.amount);
  if (isNaN(amt) || amt <= 0) {
    return 'Amount must be a positive number greater than 0';
  }
  return null;
}

// GET /api/expenses (Query with filters)
router.get('/', auth, async (req, res) => {
  try {
    const isAdmin = req.user.role === 'admin';
    const showAll = isAdmin && req.query.all === 'true';

    const filter = {};
    if (!showAll) filter.user = req.user.id;
    if (req.query.category && req.query.category !== 'All') filter.category = req.query.category;
    if (req.query.from || req.query.to) {
      filter.date = {};
      if (req.query.from) filter.date.$gte = req.query.from;
      if (req.query.to) filter.date.$lte = req.query.to;
    }
    if (req.query.search) {
      filter.$or = [
        { description: { $regex: req.query.search, $options: 'i' } },
        { category: { $regex: req.query.search, $options: 'i' } },
      ];
    }

    const expenses = await Expense.find(filter)
      .populate('user', 'name email')
      .sort({ date: -1, createdAt: -1 });

    res.json(expenses);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/expenses/stats (Aggregation analytics)
router.get('/stats', auth, async (req, res) => {
  try {
    const isAdmin = req.user.role === 'admin';
    const showAll = isAdmin && req.query.all === 'true';

    const matchStage = showAll ? {} : { user: req.user.id };
    const expenses = await Expense.find(matchStage);

    const curMonthPrefix = new Date().toISOString().slice(0, 7);
    let totalSpent = 0;
    let thisMonthSpent = 0;
    const categoryTotals = {};
    const monthlyTotals = {};

    expenses.forEach((e) => {
      totalSpent += e.amount;
      if (e.date.startsWith(curMonthPrefix)) {
        thisMonthSpent += e.amount;
      }
      categoryTotals[e.category] = (categoryTotals[e.category] || 0) + e.amount;
      const monthKey = e.date.slice(0, 7);
      monthlyTotals[monthKey] = (monthlyTotals[monthKey] || 0) + e.amount;
    });

    const categories = Object.entries(categoryTotals)
      .map(([category, amount]) => ({
        category,
        amount,
        percentage: totalSpent > 0 ? (amount / totalSpent) * 100 : 0,
      }))
      .sort((a, b) => b.amount - a.amount);

    res.json({
      totalSpent,
      thisMonthSpent,
      transactionCount: expenses.length,
      topCategory: categories[0]?.category || 'N/A',
      categories,
      monthlyTotals,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST /api/expenses (Create)
router.post('/', auth, async (req, res) => {
  try {
    const error = validateExpenseInput(req.body);
    if (error) return res.status(400).json({ message: error });

    const { date, category, amount, description } = req.body;
    const created = await Expense.create({
      user: req.user.id,
      date: date.slice(0, 10),
      category,
      amount: Number(amount),
      description: (description || '').trim(),
    });

    res.status(201).json(created);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT /api/expenses/:id (Update)
router.put('/:id', auth, async (req, res) => {
  try {
    const error = validateExpenseInput(req.body);
    if (error) return res.status(400).json({ message: error });

    const record = await Expense.findById(req.params.id);
    if (!record) return res.status(404).json({ message: 'Expense record not found' });

    if (record.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Forbidden. You can only edit your own expenses' });
    }

    const { date, category, amount, description } = req.body;
    record.date = date.slice(0, 10);
    record.category = category;
    record.amount = Number(amount);
    record.description = (description || '').trim();

    await record.save();
    res.json(record);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// DELETE /api/expenses/:id (Delete)
router.delete('/:id', auth, async (req, res) => {
  try {
    const record = await Expense.findById(req.params.id);
    if (!record) return res.status(404).json({ message: 'Expense record not found' });

    if (record.user.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Forbidden. You can only delete your own expenses' });
    }

    await Expense.findByIdAndDelete(req.params.id);
    res.json({ message: 'Expense deleted successfully', id: req.params.id });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;