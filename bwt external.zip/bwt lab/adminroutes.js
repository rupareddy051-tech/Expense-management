const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Expense = require('../models/Expense');
const { auth, adminOnly } = require('../middleware/auth');

router.use(auth);
router.use(adminOnly);

// GET /api/admin/users
router.get('/users', async (req, res) => {
  try {
    const users = await User.find().select('-password');
    const expenses = await Expense.find();

    const totals = {};
    expenses.forEach((e) => {
      const uId = e.user.toString();
      if (!totals[uId]) totals[uId] = { total: 0, count: 0 };
      totals[uId].total += e.amount;
      totals[uId].count += 1;
    });

    const userList = users.map((u) => ({
      _id: u._id,
      name: u.name,
      email: u.email,
      role: u.role,
      createdAt: u.createdAt,
      totalSpent: totals[u._id.toString()]?.total || 0,
      expenseCount: totals[u._id.toString()]?.count || 0,
    }));

    res.json(userList);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// DELETE /api/admin/users/:id
router.delete('/users/:id', async (req, res) => {
  try {
    const targetId = req.params.id;

    if (targetId === req.user.id) {
      return res.status(400).json({
        message: 'Security protection: Administrator cannot delete their own account.',
      });
    }

    const deletedExpenses = await Expense.deleteMany({ user: targetId });
    const deletedUser = await User.findByIdAndDelete(targetId);

    if (!deletedUser) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({
      message: 'User and all associated expenses deleted successfully',
      deletedExpensesCount: deletedExpenses.deletedCount,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;