export type ExpenseCategory =
  | 'Food'
  | 'Travel'
  | 'Shopping'
  | 'Bills'
  | 'Education'
  | 'Health'
  | 'Entertainment'
  | 'Other';

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
}

export interface Expense {
  _id: string;
  user: {
    _id: string;
    name: string;
    email: string;
  } | null;
  date: string;
  category: ExpenseCategory;
  amount: number;
  description: string;
  createdAt: string;
  updatedAt: string;
}

export interface CategorySummary {
  category: ExpenseCategory;
  amount: number;
  percentage: number;
}

export interface ExpenseStats {
  totalSpent: number;
  thisMonthSpent: number;
  transactionCount: number;
  topCategory: string;
  categories: CategorySummary[];
  monthlyTotals: Record<string, number>;
}

export interface AdminUserRecord {
  _id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
  createdAt: string;
  totalSpent: number;
  expenseCount: number;
}

export interface ProjectInfo {
  title: string;
  problemStatementNumber: string;
  description: string;
  developer: {
    name: string;
    role: string;
    institution: string;
  };
  objectives: string[];
  stack: {
    database: string;
    backend: string;
    frontend: string;
    security: string;
  };
  restEndpoints: Array<{
    method: string;
    path: string;
    desc: string;
  }>;
}

export interface MongoCollectionsData {
  database: string;
  collections: {
    users: {
      count: number;
      schema: Record<string, string>;
      documents: any[];
    };
    expenses: {
      count: number;
      schema: Record<string, string>;
      documents: any[];
    };
  };
}
