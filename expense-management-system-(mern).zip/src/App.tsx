import React, { useState, useEffect, useCallback } from 'react';
import {
  Header,
} from './components/Header';
import { ProjectBanner } from './components/ProjectBanner';
import { StatsOverview } from './components/StatsOverview';
import { ExpenseTable } from './components/ExpenseTable';
import { ExpenseFormModal } from './components/ExpenseFormModal';
import { AdminPanel } from './components/AdminPanel';
import { AnalyticsView } from './components/AnalyticsView';
import { MongoInspectorModal } from './components/MongoInspectorModal';
import { ProjectInfoModal } from './components/ProjectInfoModal';
import { AuthModal } from './components/AuthModal';
import {
  User,
  Expense,
  ExpenseStats,
  ExpenseCategory,
} from './types';
import {
  api,
  getStoredToken,
  getStoredUser,
  clearStoredAuth,
  setStoredAuth,
} from './services/api';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(getStoredUser());
  const [authToken, setAuthToken] = useState<string | null>(getStoredToken());
  const [initializing, setInitializing] = useState<boolean>(true);

  // Navigation & View state
  const [activeTab, setActiveTab] = useState<'expenses' | 'analytics' | 'admin'>('expenses');
  const [isAdminView, setIsAdminView] = useState<boolean>(false);

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [isMongoModalOpen, setIsMongoModalOpen] = useState<boolean>(false);
  const [isProjectInfoModalOpen, setIsProjectInfoModalOpen] = useState<boolean>(false);
  const [projectInfoTab, setProjectInfoTab] = useState<'overview' | 'api' | 'architecture' | 'source_code'>('overview');

  const openProjectInfo = (tab: 'overview' | 'api' | 'architecture' | 'source_code' = 'overview') => {
    setProjectInfoTab(tab);
    setIsProjectInfoModalOpen(true);
  };

  // Data state
  const [categories, setCategories] = useState<ExpenseCategory[]>([
    'Food',
    'Travel',
    'Shopping',
    'Bills',
    'Education',
    'Health',
    'Entertainment',
    'Other',
  ]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [stats, setStats] = useState<ExpenseStats | null>(null);
  const [loadingExpenses, setLoadingExpenses] = useState<boolean>(false);
  const [loadingStats, setLoadingStats] = useState<boolean>(false);

  // Filters
  const [filterCategory, setFilterCategory] = useState<string>('All');
  const [filterFrom, setFilterFrom] = useState<string>('');
  const [filterTo, setFilterTo] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Toast feedback notifications
  const [toast, setToast] = useState<{ message: string; isError?: boolean } | null>(null);

  const showToast = useCallback((message: string, isError = false) => {
    setToast({ message, isError });
    setTimeout(() => {
      setToast(null);
    }, 3500);
  }, []);

  // Fetch initial profile & check session validity
  useEffect(() => {
    const checkAuth = async () => {
      const token = getStoredToken();
      if (!token) {
        // If not logged in yet, automatically login with default demo admin (Mantri Sreeja)
        // so the app is instantly usable and interactive out of the box!
        try {
          const res = await api.login({
            email: 'sreeja@mallareddy.ac.in',
            password: 'admin123',
          });
          setStoredAuth(res.token, res.user);
          setAuthToken(res.token);
          setCurrentUser(res.user);
        } catch {
          setCurrentUser(null);
        }
        setInitializing(false);
        return;
      }

      try {
        const user = await api.getMe();
        setCurrentUser(user);
      } catch {
        clearStoredAuth();
        setCurrentUser(null);
        setAuthToken(null);
      } finally {
        setInitializing(false);
      }
    };

    checkAuth();
  }, []);

  // Fetch categories
  useEffect(() => {
    api.getCategories().then(setCategories).catch(console.error);
  }, []);

  // Fetch Expenses with filters
  const loadExpenses = useCallback(async () => {
    if (!currentUser) return;
    try {
      setLoadingExpenses(true);
      const data = await api.getExpenses({
        category: filterCategory,
        from: filterFrom,
        to: filterTo,
        search: searchQuery,
        all: isAdminView,
      });
      setExpenses(data);
    } catch (err: any) {
      if (err.message?.includes('login') || err.message?.includes('token')) {
        handleLogout();
      } else {
        showToast(err.message || 'Failed to load expenses', true);
      }
    } finally {
      setLoadingExpenses(false);
    }
  }, [currentUser, filterCategory, filterFrom, filterTo, searchQuery, isAdminView, showToast]);

  // Fetch Statistics
  const loadStats = useCallback(async () => {
    if (!currentUser) return;
    try {
      setLoadingStats(true);
      const data = await api.getStats(isAdminView);
      setStats(data);
    } catch (err: any) {
      console.warn('Stats fetch warning:', err);
    } finally {
      setLoadingStats(false);
    }
  }, [currentUser, isAdminView]);

  useEffect(() => {
    if (currentUser) {
      loadExpenses();
      loadStats();
    }
  }, [loadExpenses, loadStats, currentUser]);

  // Logout handler
  const handleLogout = () => {
    clearStoredAuth();
    setCurrentUser(null);
    setAuthToken(null);
    setExpenses([]);
    setStats(null);
    setActiveTab('expenses');
    showToast('Logged out successfully.');
  };

  // Quick Switch demo user
  const handleQuickSwitchUser = async (role: 'admin' | 'user') => {
    try {
      const email =
        role === 'admin' ? 'sreeja@mallareddy.ac.in' : 'rahul.varma@gmail.com';
      const password = role === 'admin' ? 'admin123' : 'user123';

      const res = await api.login({ email, password });
      setStoredAuth(res.token, res.user);
      setAuthToken(res.token);
      setCurrentUser(res.user);
      setIsAdminView(false);
      if (role !== 'admin' && activeTab === 'admin') {
        setActiveTab('expenses');
      }
      showToast(`Switched session to ${res.user.name} (${res.user.role.toUpperCase()})`);
    } catch (err: any) {
      showToast(err.message || 'Quick switch failed', true);
    }
  };

  // Create / Update Expense
  const handleSaveExpense = async (data: {
    date: string;
    category: ExpenseCategory;
    amount: number;
    description: string;
  }) => {
    if (editingExpense) {
      await api.updateExpense(editingExpense._id, data);
      showToast('Expense record updated in MongoDB.');
      setEditingExpense(null);
    } else {
      await api.createExpense(data);
      showToast('New expense record saved to MongoDB.');
    }
    loadExpenses();
    loadStats();
  };

  // Delete Expense
  const handleDeleteExpense = async (id: string) => {
    const confirmed = window.confirm('Are you sure you want to delete this expense record?');
    if (!confirmed) return;

    try {
      await api.deleteExpense(id);
      showToast('Expense removed from MongoDB.');
      loadExpenses();
      loadStats();
    } catch (err: any) {
      showToast(err.message || 'Failed to delete expense', true);
    }
  };

  if (initializing) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="text-center space-y-3">
          <div className="w-8 h-8 border-3 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs text-slate-500 font-mono">
            Bootstrapping MERN Expense Management Prototype...
          </p>
        </div>
      </div>
    );
  }

  // If not logged in, render the Auth Form
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col">
        <ProjectBanner
          onOpenProjectInfo={openProjectInfo}
          onOpenMongoInspector={() => setIsMongoModalOpen(true)}
        />
        <main className="flex-1">
          <AuthModal
            onSuccess={(u) => {
              setCurrentUser(u);
              showToast(`Welcome, ${u.name}!`);
            }}
            onOpenProjectInfo={openProjectInfo}
          />
        </main>
        {isProjectInfoModalOpen && (
          <ProjectInfoModal
            isOpen={isProjectInfoModalOpen}
            onClose={() => setIsProjectInfoModalOpen(false)}
            defaultTab={projectInfoTab}
          />
        )}
        {isMongoModalOpen && (
          <MongoInspectorModal
            isOpen={isMongoModalOpen}
            onClose={() => setIsMongoModalOpen(false)}
          />
        )}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col text-slate-900">
      {/* Toast Notification */}
      {toast && (
        <div className="fixed bottom-5 right-5 z-50 animate-in fade-in slide-in-from-bottom-4 duration-200">
          <div
            className={`px-4 py-3 rounded-xl shadow-lg border text-xs font-medium ${
              toast.isError
                ? 'bg-rose-900 text-white border-rose-800'
                : 'bg-slate-900 text-white border-slate-800'
            }`}
          >
            {toast.message}
          </div>
        </div>
      )}

      {/* Academic Project Banner */}
      <ProjectBanner
        onOpenProjectInfo={openProjectInfo}
        onOpenMongoInspector={() => setIsMongoModalOpen(true)}
      />

      {/* Main Top Header Navigation */}
      <Header
        user={currentUser}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAddExpense={() => {
          setEditingExpense(null);
          setIsAddModalOpen(true);
        }}
        onOpenMongoInspector={() => setIsMongoModalOpen(true)}
        onOpenProjectInfo={openProjectInfo}
        onLogout={handleLogout}
        onQuickSwitchUser={handleQuickSwitchUser}
      />

      {/* Main Viewport Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'expenses' && (
          <div className="space-y-6">
            <StatsOverview
              stats={stats}
              loading={loadingStats}
              isAdminView={isAdminView}
            />

            <ExpenseTable
              expenses={expenses}
              loading={loadingExpenses}
              currentUser={currentUser}
              isAdminView={isAdminView}
              setIsAdminView={setIsAdminView}
              categories={categories}
              filterCategory={filterCategory}
              setFilterCategory={setFilterCategory}
              filterFrom={filterFrom}
              setFilterFrom={setFilterFrom}
              filterTo={filterTo}
              setFilterTo={setFilterTo}
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              onEdit={(exp) => {
                setEditingExpense(exp);
                setIsAddModalOpen(true);
              }}
              onDelete={handleDeleteExpense}
              onOpenAddExpense={() => {
                setEditingExpense(null);
                setIsAddModalOpen(true);
              }}
            />
          </div>
        )}

        {activeTab === 'analytics' && (
          <AnalyticsView
            stats={stats}
            loading={loadingStats}
            isAdminView={isAdminView}
          />
        )}

        {activeTab === 'admin' && currentUser.role === 'admin' && (
          <AdminPanel
            currentUser={currentUser}
            onRefreshExpenses={() => {
              loadExpenses();
              loadStats();
            }}
            showToast={showToast}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-5 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>
            Problem Statement 49: Expense Management (MERN Stack)
          </span>
          <span>
            Developed &amp; Presented by <strong className="text-slate-800">Mantri Sreeja</strong> · Malla Reddy Vishwavidyapeeth Technical Campus
          </span>
        </div>
      </footer>

      {/* Modals */}
      <ExpenseFormModal
        isOpen={isAddModalOpen}
        onClose={() => {
          setIsAddModalOpen(false);
          setEditingExpense(null);
        }}
        onSave={handleSaveExpense}
        editingExpense={editingExpense}
        categories={categories}
      />

      <MongoInspectorModal
        isOpen={isMongoModalOpen}
        onClose={() => setIsMongoModalOpen(false)}
      />

      <ProjectInfoModal
        isOpen={isProjectInfoModalOpen}
        onClose={() => setIsProjectInfoModalOpen(false)}
        defaultTab={projectInfoTab}
      />
    </div>
  );
}
