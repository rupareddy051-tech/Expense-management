import {
  User,
  Expense,
  ExpenseStats,
  AdminUserRecord,
  ProjectInfo,
  MongoCollectionsData,
  ExpenseCategory,
} from '../types';

const TOKEN_KEY = 'mern_expense_auth_token';
const USER_KEY = 'mern_expense_auth_user';

export const getStoredToken = (): string | null => localStorage.getItem(TOKEN_KEY);
export const getStoredUser = (): User | null => {
  const data = localStorage.getItem(USER_KEY);
  return data ? JSON.parse(data) : null;
};

export const setStoredAuth = (token: string, user: User) => {
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(USER_KEY, JSON.stringify(user));
};

export const clearStoredAuth = () => {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
};

async function request<T>(
  path: string,
  options: {
    method?: string;
    body?: any;
    token?: string | null;
  } = {}
): Promise<T> {
  const { method = 'GET', body, token } = options;
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  const activeToken = token !== undefined ? token : getStoredToken();
  if (activeToken) {
    headers.Authorization = `Bearer ${activeToken}`;
  }

  const response = await fetch(path, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data.message || `Request failed with status ${response.status}`);
  }

  return data as T;
}

export const api = {
  // Auth
  async register(payload: {
    name: string;
    email: string;
    password: string;
    rolePreference?: 'user' | 'admin';
  }): Promise<{ token: string; user: User }> {
    return request('/api/auth/register', { method: 'POST', body: payload });
  },

  async login(payload: { email: string; password: string }): Promise<{ token: string; user: User }> {
    return request('/api/auth/login', { method: 'POST', body: payload });
  },

  async getMe(): Promise<User> {
    return request('/api/auth/me');
  },

  // Categories
  async getCategories(): Promise<ExpenseCategory[]> {
    return request('/api/categories');
  },

  // Expenses CRUD
  async getExpenses(filters?: {
    category?: string;
    from?: string;
    to?: string;
    search?: string;
    all?: boolean;
  }): Promise<Expense[]> {
    const params = new URLSearchParams();
    if (filters?.category && filters.category !== 'All') {
      params.set('category', filters.category);
    }
    if (filters?.from) params.set('from', filters.from);
    if (filters?.to) params.set('to', filters.to);
    if (filters?.search) params.set('search', filters.search);
    if (filters?.all) params.set('all', 'true');

    const query = params.toString() ? `?${params.toString()}` : '';
    return request(`/api/expenses${query}`);
  },

  async createExpense(expense: {
    date: string;
    category: ExpenseCategory;
    amount: number;
    description: string;
  }): Promise<Expense> {
    return request('/api/expenses', { method: 'POST', body: expense });
  },

  async updateExpense(
    id: string,
    expense: {
      date: string;
      category: ExpenseCategory;
      amount: number;
      description: string;
    }
  ): Promise<Expense> {
    return request(`/api/expenses/${id}`, { method: 'PUT', body: expense });
  },

  async deleteExpense(id: string): Promise<{ message: string; id: string }> {
    return request(`/api/expenses/${id}`, { method: 'DELETE' });
  },

  // Analytics
  async getStats(showAll = false): Promise<ExpenseStats> {
    const query = showAll ? '?all=true' : '';
    return request(`/api/expenses/stats${query}`);
  },

  // Admin
  async getAdminUsers(): Promise<AdminUserRecord[]> {
    return request('/api/admin/users');
  },

  async deleteAdminUser(id: string): Promise<{ message: string }> {
    return request(`/api/admin/users/${id}`, { method: 'DELETE' });
  },

  // Academic / MERN Metadata
  async getProjectInfo(): Promise<ProjectInfo> {
    return request('/api/project-info');
  },

  async inspectMongo(): Promise<MongoCollectionsData> {
    return request('/api/mongodb/inspect');
  },

  async resetSeedData(): Promise<{ message: string }> {
    return request('/api/mongodb/reset-seed', { method: 'POST' });
  },

  async getSourceCode(): Promise<{
    filename: string;
    language: string;
    developer: string;
    college: string;
    code: string;
  }> {
    return request('/api/source-code');
  },
};

