import React from 'react';
import { Layers, GraduationCap, CheckCircle2, FileCode, Database } from 'lucide-react';

interface ProjectBannerProps {
  onOpenProjectInfo: (tab?: 'overview' | 'api' | 'architecture' | 'source_code') => void;
  onOpenMongoInspector: () => void;
}

export const ProjectBanner: React.FC<ProjectBannerProps> = ({
  onOpenProjectInfo,
  onOpenMongoInspector,
}) => {
  return (
    <div className="bg-slate-900 text-slate-100 border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs">
          {/* Left: Project & Presenter Info */}
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
            <span className="font-semibold text-white tracking-wide">
              49. Expense Management
            </span>
            <span className="text-slate-500" aria-hidden="true">·</span>
            <span className="text-slate-300">
              Developer &amp; Presenter: <strong className="text-white font-medium">Mantri Sreeja</strong>
            </span>
            <span className="text-slate-500" aria-hidden="true">·</span>
            <span className="text-slate-400">
              Malla Reddy Vishwavidyapeeth Technical Campus
            </span>
            <span className="text-slate-500" aria-hidden="true">·</span>
            <span className="text-amber-300 font-mono text-[11px]">
              Language: JavaScript (.js)
            </span>
          </div>

          {/* Right: MERN Stack verification tags & quick triggers */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => onOpenProjectInfo('source_code')}
              className="px-2.5 py-1 rounded bg-amber-950/80 hover:bg-amber-900 text-amber-300 hover:text-amber-200 border border-amber-800 transition-colors flex items-center gap-1 font-medium"
            >
              <FileCode className="w-3 h-3 text-amber-400" />
              <span>server.js (JS Code)</span>
            </button>
            <button
              onClick={() => onOpenProjectInfo('overview')}
              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white transition-colors"
            >
              Viva &amp; Specs
            </button>
            <button
              onClick={onOpenMongoInspector}
              className="px-2.5 py-1 rounded bg-emerald-950 hover:bg-emerald-900 text-emerald-300 hover:text-emerald-200 border border-emerald-800 transition-colors flex items-center gap-1"
            >
              <Database className="w-3 h-3 text-emerald-400" />
              <span>Live DB</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
