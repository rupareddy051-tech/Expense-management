import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  Users,
  Trash2,
  RefreshCw,
  AlertTriangle,
  Database,
  CheckCircle,
} from 'lucide-react';
import { AdminUserRecord, User } from '../types';
import { api } from '../services/api';
import { formatINR } from './StatsOverview';

interface AdminPanelProps {
  currentUser: User;
  onRefreshExpenses: () => void;
  showToast: (msg: string, isError?: boolean) => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  currentUser,
  onRefreshExpenses,
  showToast,
}) => {
  const [users, setUsers] = useState<AdminUserRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [resetting, setResetting] = useState<boolean>(false);

  const loadUsers = async () => {
    try {
      setLoading(true);
      const data = await api.getAdminUsers();
      setUsers(data);
    } catch (err: any) {
      showToast(err.message || 'Failed to load user records', true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const handleDeleteUser = async (userRecord: AdminUserRecord) => {
    if (userRecord._id === currentUser.id) {
      showToast('You cannot delete your own active administrator account.', true);
      return;
    }

    const confirmDelete = window.confirm(
      `Delete user "${userRecord.name}" (${userRecord.email})? This will also remove all ${userRecord.expenseCount} associated expenses from MongoDB.`
    );
    if (!confirmDelete) return;

    try {
      await api.deleteAdminUser(userRecord._id);
      showToast(`User ${userRecord.name} and their records were successfully removed.`);
      loadUsers();
      onRefreshExpenses();
    } catch (err: any) {
      showToast(err.message || 'Failed to delete user', true);
    }
  };

  const handleResetSeed = async () => {
    const confirmReset = window.confirm(
      'Reset MongoDB store back to default demonstration dataset? This will restore Mantri Sreeja (Admin) and sample expenses.'
    );
    if (!confirmReset) return;

    try {
      setResetting(true);
      await api.resetSeedData();
      showToast('Database successfully reloaded with clean seed data.');
      loadUsers();
      onRefreshExpenses();
    } catch (err: any) {
      showToast(err.message || 'Failed to reset seed data', true);
    } finally {
      setResetting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header card */}
      <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-semibold text-slate-900">
              User &amp; Role Management (RBAC)
            </h2>
            <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-amber-100 text-amber-800 font-semibold">
              Admin Exclusive
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Manage registered accounts, view aggregated user expenditures, and manage database state.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={loadUsers}
            className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors inline-flex items-center gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh</span>
          </button>
          <button
            onClick={handleResetSeed}
            disabled={resetting}
            className="px-3 py-1.5 text-xs font-medium text-amber-700 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-lg transition-colors inline-flex items-center gap-1.5 disabled:opacity-50"
          >
            <Database className="w-3.5 h-3.5" />
            <span>{resetting ? 'Resetting...' : 'Reload Seed Data'}</span>
          </button>
        </div>
      </div>

      {/* Users table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-900">
            Registered Users ({users.length})
          </h3>
          <span className="text-xs text-slate-500">
            RBAC Access Rules Enforced via Express Middleware
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-3 px-4">User</th>
                <th className="py-3 px-4">Role</th>
                <th className="py-3 px-4">Joined Date</th>
                <th className="py-3 px-4 text-center">Expense Count</th>
                <th className="py-3 px-4 text-right">Total Spent (₹)</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {loading ? (
                <tr>
                  <td colSpan={6} className="py-10 text-center text-slate-400">
                    Loading users from MongoDB collection...
                  </td>
                </tr>
              ) : (
                users.map((u) => {
                  const isCurrent = u._id === currentUser.id;

                  return (
                    <tr
                      key={u._id}
                      className="hover:bg-slate-50/80 transition-colors"
                    >
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-900">
                          {u.name} {isCurrent && <span className="text-xs text-indigo-600 font-semibold">(You)</span>}
                        </div>
                        <div className="text-[11px] font-mono text-slate-500">
                          {u.email}
                        </div>
                      </td>
                      <td className="py-3 px-4 font-mono text-xs">
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[11px] font-semibold ${
                            u.role === 'admin'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-sky-100 text-sky-800'
                          }`}
                        >
                          {u.role.toUpperCase()}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono tabular-nums text-slate-600">
                        {u.createdAt.slice(0, 10)}
                      </td>
                      <td className="py-3 px-4 text-center font-mono tabular-nums font-semibold text-slate-700">
                        {u.expenseCount}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums font-semibold text-slate-900">
                        {formatINR(u.totalSpent)}
                      </td>
                      <td className="py-3 px-4 text-right">
                        {isCurrent ? (
                          <span className="text-[11px] text-slate-400 italic">
                            Protected
                          </span>
                        ) : (
                          <button
                            onClick={() => handleDeleteUser(u)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-rose-700 hover:text-white hover:bg-rose-600 border border-rose-200 rounded-md transition-colors"
                          >
                            <Trash2 className="w-3 h-3" />
                            <span>Delete</span>
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
