import React, { useState, useEffect } from 'react';
import {
  X,
  GraduationCap,
  Layers,
  Server,
  Database,
  Code2,
  CheckCircle2,
  Copy,
  Check,
  Download,
  FileCode,
} from 'lucide-react';
import { ProjectInfo } from '../types';
import { api } from '../services/api';

interface ProjectInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultTab?: 'overview' | 'api' | 'architecture' | 'source_code';
}

export const ProjectInfoModal: React.FC<ProjectInfoModalProps> = ({
  isOpen,
  onClose,
  defaultTab = 'overview',
}) => {
  const [info, setInfo] = useState<ProjectInfo | null>(null);
  const [sourceCodeData, setSourceCodeData] = useState<{
    filename: string;
    language: string;
    developer: string;
    college: string;
    code: string;
  } | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'api' | 'architecture' | 'source_code'>(
    defaultTab
  );
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      if (!info) api.getProjectInfo().then(setInfo).catch(console.error);
      if (!sourceCodeData) api.getSourceCode().then(setSourceCodeData).catch(console.error);
      setActiveTab(defaultTab);
    }
  }, [isOpen, defaultTab]);

  if (!isOpen) return null;

  const handleCopyCode = () => {
    if (!sourceCodeData?.code) return;
    navigator.clipboard.writeText(sourceCodeData.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadCode = () => {
    if (!sourceCodeData?.code) return;
    const blob = new Blob([sourceCodeData.code], { type: 'text/javascript' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'server.js';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-indigo-600 text-white flex items-center justify-center shadow-xs">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                49. Expense Management System
              </h2>
              <p className="text-xs text-slate-600">
                Project Documentation &amp; Subjective JavaScript Source Code
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-1 px-6 pt-3 border-b border-slate-200 text-xs overflow-x-auto">
          <button
            onClick={() => setActiveTab('overview')}
            className={`pb-2.5 px-3 font-semibold transition-colors border-b-2 whitespace-nowrap ${
              activeTab === 'overview'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Project Overview &amp; Objectives
          </button>
          <button
            onClick={() => setActiveTab('source_code')}
            className={`pb-2.5 px-3 font-semibold transition-colors border-b-2 whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'source_code'
                ? 'border-amber-600 text-amber-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <FileCode className="w-3.5 h-3.5 text-amber-600" />
            <span>JavaScript Code (server.js)</span>
          </button>
          <button
            onClick={() => setActiveTab('architecture')}
            className={`pb-2.5 px-3 font-semibold transition-colors border-b-2 whitespace-nowrap ${
              activeTab === 'architecture'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            MERN Architecture &amp; Models
          </button>
          <button
            onClick={() => setActiveTab('api')}
            className={`pb-2.5 px-3 font-semibold transition-colors border-b-2 whitespace-nowrap ${
              activeTab === 'api'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            REST API Directory
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-xs text-slate-700">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Presenter Metadata Card */}
              <div className="p-4 bg-indigo-50/60 border border-indigo-100 rounded-xl space-y-2">
                <div className="text-xs font-semibold text-indigo-900">
                  Candidate &amp; Academic Information
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-slate-500">Developer &amp; Presenter:</span>{' '}
                    <strong className="text-slate-900">Mantri Sreeja</strong>
                  </div>
                  <div>
                    <span className="text-slate-500">Problem Statement:</span>{' '}
                    <strong className="text-slate-900">49. Expense Management</strong>
                  </div>
                  <div>
                    <span className="text-slate-500">Programming Language:</span>{' '}
                    <strong className="text-slate-900">JavaScript (Node.js + React.js)</strong>
                  </div>
                  <div>
                    <span className="text-slate-500">Target File:</span>{' '}
                    <strong className="text-slate-900 font-mono">server.js</strong>
                  </div>
                  <div className="sm:col-span-2">
                    <span className="text-slate-500">College / Institution:</span>{' '}
                    <strong className="text-slate-900">
                      Malla Reddy Vishwavidyapeeth Technical Campus
                    </strong>
                  </div>
                </div>
              </div>

              {/* Objectives Completed Checklist */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Project Objectives &amp; Requirements Checklist
                </h3>
                <div className="space-y-2">
                  {[
                    'Demonstrate MERN Stack development (MongoDB, Express.js, React.js, Node.js).',
                    'Write subjective implementation in JavaScript (JS) using Node.js & Express.',
                    'Implement full CRUD operations using MongoDB (Create, Read, Update, Delete).',
                    'Build structured RESTful APIs using Node.js and Express.js in JavaScript.',
                    'Develop high-fidelity, interactive frontend using React.js with real-time state.',
                    'Implement authentication and Role-Based Access Control (RBAC: Admin vs User).',
                    'Display project information, aggregated results, and spending analytics clearly.',
                  ].map((obj, i) => (
                    <div
                      key={i}
                      className="flex items-start gap-2.5 p-2.5 bg-slate-50 rounded-lg border border-slate-100"
                    >
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span className="text-slate-800 leading-relaxed font-medium">
                        {obj}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Demo Credentials for Examination */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                <div className="text-xs font-semibold text-slate-900">
                  Pre-configured Accounts for Testing &amp; Viva
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-3 bg-white rounded-lg border border-slate-200">
                    <div className="font-semibold text-amber-800 mb-1 flex items-center justify-between">
                      <span>Administrator Account</span>
                      <span className="text-[10px] font-mono bg-amber-100 px-1.5 py-0.5 rounded">
                        ROLE: ADMIN
                      </span>
                    </div>
                    <div className="font-mono text-[11px] text-slate-600">
                      Email: sreeja@mallareddy.ac.in<br />
                      Password: admin123
                    </div>
                    <div className="text-[11px] text-slate-500 mt-1">
                      Privileges: Full CRUD + View all users expenses + Manage users
                    </div>
                  </div>

                  <div className="p-3 bg-white rounded-lg border border-slate-200">
                    <div className="font-semibold text-sky-800 mb-1 flex items-center justify-between">
                      <span>Standard User Account</span>
                      <span className="text-[10px] font-mono bg-sky-100 px-1.5 py-0.5 rounded">
                        ROLE: USER
                      </span>
                    </div>
                    <div className="font-mono text-[11px] text-slate-600">
                      Email: rahul.varma@gmail.com<br />
                      Password: user123
                    </div>
                    <div className="text-[11px] text-slate-500 mt-1">
                      Privileges: Personal expense tracking &amp; personal analytics
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: PURE JAVASCRIPT SOURCE CODE (server.js) */}
          {activeTab === 'source_code' && (
            <div className="space-y-4">
              <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div>
                  <div className="font-semibold text-amber-900 flex items-center gap-2">
                    <FileCode className="w-4 h-4 text-amber-700" />
                    <span>Pure JavaScript Implementation: <code className="font-mono font-bold">server.js</code></span>
                  </div>
                  <p className="text-slate-600 text-[11px] mt-0.5">
                    Written in standard JavaScript (ES6+ / CommonJS) for Node.js. Runnable with <code className="font-mono bg-white px-1.5 py-0.5 rounded border border-amber-200">node server.js</code>.
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={handleCopyCode}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg text-slate-800 font-medium transition-colors shadow-xs"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="text-emerald-700 font-semibold">Copied JS!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-slate-600" />
                        <span>Copy Code</span>
                      </>
                    )}
                  </button>
                  <button
                    onClick={handleDownloadCode}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-medium transition-colors shadow-xs"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download server.js</span>
                  </button>
                </div>
              </div>

              {/* Code viewer box */}
              <div className="bg-slate-950 text-slate-100 rounded-xl border border-slate-800 overflow-hidden shadow-inner">
                <div className="px-4 py-2 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                  <span>server.js (Node.js + Express.js + MongoDB Models)</span>
                  <span className="text-amber-400 font-semibold">Language: JavaScript</span>
                </div>
                <div className="p-4 max-h-[500px] overflow-y-auto overflow-x-auto text-xs font-mono leading-relaxed text-sky-200 selection:bg-indigo-600 selection:text-white">
                  <pre className="whitespace-pre">
                    {sourceCodeData?.code || '// Loading server.js JavaScript code...'}
                  </pre>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: ARCHITECTURE */}
          {activeTab === 'architecture' && (
            <div className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5">
                  <div className="font-semibold text-emerald-800 flex items-center gap-2">
                    <Database className="w-4 h-4 text-emerald-600" />
                    <span>M - MongoDB (Database)</span>
                  </div>
                  <p className="text-slate-600 text-[11px] leading-relaxed">
                    Stores documents in User and Expense collections. Utilizes ObjectId references, indexing, schema validations, and aggregation pipelines ($group, $sum) for financial analytics.
                  </p>
                </div>

                <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5">
                  <div className="font-semibold text-sky-800 flex items-center gap-2">
                    <Server className="w-4 h-4 text-sky-600" />
                    <span>E - Express.js (REST Backend in JS)</span>
                  </div>
                  <p className="text-slate-600 text-[11px] leading-relaxed">
                    Provides clean modular routing, JSON parsing, error boundary handling, and authorization middlewares (auth, adminOnly).
                  </p>
                </div>

                <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5">
                  <div className="font-semibold text-indigo-800 flex items-center gap-2">
                    <Code2 className="w-4 h-4 text-indigo-600" />
                    <span>R - React.js (Frontend UI in JS)</span>
                  </div>
                  <p className="text-slate-600 text-[11px] leading-relaxed">
                    Modern component-driven interface built with React, hooks (useState, useEffect, useMemo), Tailwind CSS, responsive tables, and interactive modals.
                  </p>
                </div>

                <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5">
                  <div className="font-semibold text-emerald-800 flex items-center gap-2">
                    <Layers className="w-4 h-4 text-emerald-600" />
                    <span>N - Node.js (JavaScript Runtime)</span>
                  </div>
                  <p className="text-slate-600 text-[11px] leading-relaxed">
                    High-throughput asynchronous JavaScript runtime hosting Express, token signing with jsonwebtoken, and password hashing via bcryptjs.
                  </p>
                </div>
              </div>

              {/* Data Schemas */}
              <div className="p-4 bg-slate-900 text-slate-100 rounded-xl space-y-3 font-mono text-[11px]">
                <div className="text-slate-400 font-sans font-semibold text-xs">
                  MongoDB Schema Structures in JavaScript
                </div>
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                  <span className="text-emerald-400">// Expense Schema (JavaScript)</span>
                  <br />
                  user: mongoose.Schema.Types.ObjectId (ref: 'User', required: true)
                  <br />
                  date: Date (required: true)
                  <br />
                  category: String (enum: ['Food','Travel','Shopping','Bills','Education','Health','Entertainment','Other'])
                  <br />
                  amount: Number (required: true, min: 0.01)
                  <br />
                  description: String (trim: true)
                  <br />
                  timestamps: true (createdAt, updatedAt)
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: API DIRECTORY */}
          {activeTab === 'api' && (
            <div className="space-y-4">
              <p className="text-slate-600">
                All backend REST endpoints implemented in JavaScript with JWT bearer token verification:
              </p>

              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold">
                      <th className="py-2.5 px-3">Method</th>
                      <th className="py-2.5 px-3 font-mono">Endpoint Path</th>
                      <th className="py-2.5 px-3">Purpose</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
                    {[
                      { m: 'POST', p: '/api/auth/register', d: 'Register user (first account auto-promoted to Admin)' },
                      { m: 'POST', p: '/api/auth/login', d: 'Issue signed JWT token' },
                      { m: 'GET', p: '/api/auth/me', d: 'Validate token and return current session user' },
                      { m: 'GET', p: '/api/expenses', d: 'Retrieve expenses (filters: category, from, to, search, all)' },
                      { m: 'POST', p: '/api/expenses', d: 'Create expense with date, category, amount, description' },
                      { m: 'PUT', p: '/api/expenses/:id', d: 'Update expense record (enforces ownership or admin)' },
                      { m: 'DELETE', p: '/api/expenses/:id', d: 'Delete expense record (enforces ownership or admin)' },
                      { m: 'GET', p: '/api/expenses/stats', d: 'Calculate total spend, monthly spend, category breakdown' },
                      { m: 'GET', p: '/api/admin/users', d: 'List users with computed spend & count (admin only)' },
                      { m: 'DELETE', p: '/api/admin/users/:id', d: 'Delete user and cascading delete of their expenses' },
                      { m: 'GET', p: '/api/source-code', d: 'Returns complete server.js JavaScript source code' },
                      { m: 'GET', p: '/api/mongodb/inspect', d: 'Return live BSON collections for demonstration' },
                      { m: 'POST', p: '/api/mongodb/reset-seed', d: 'Reload initial seed demonstration dataset' },
                    ].map((row, idx) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="py-2.5 px-3">
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                              row.m === 'GET'
                                ? 'bg-sky-100 text-sky-800'
                                : row.m === 'POST'
                                ? 'bg-emerald-100 text-emerald-800'
                                : row.m === 'PUT'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {row.m}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-slate-800 font-semibold">{row.p}</td>
                        <td className="py-2.5 px-3 font-sans text-slate-600">{row.d}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-100 bg-slate-50 flex items-center justify-between text-xs text-slate-500">
          <span>Mantri Sreeja · Malla Reddy Vishwavidyapeeth Technical Campus</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-medium transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
