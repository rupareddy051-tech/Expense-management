import React, { useState, useEffect } from 'react';
import { X, Database, RefreshCw, Copy, Check, FileJson } from 'lucide-react';
import { MongoCollectionsData } from '../types';
import { api } from '../services/api';

interface MongoInspectorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MongoInspectorModal: React.FC<MongoInspectorModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [data, setData] = useState<MongoCollectionsData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [activeCollection, setActiveCollection] = useState<'expenses' | 'users'>(
    'expenses'
  );
  const [copied, setCopied] = useState<boolean>(false);

  const loadData = async () => {
    try {
      setLoading(true);
      const res = await api.inspectMongo();
      setData(res);
    } catch (err) {
      console.error('Failed to inspect database:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadData();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const currentDocs =
    activeCollection === 'expenses'
      ? data?.collections.expenses.documents || []
      : data?.collections.users.documents || [];

  const currentSchema =
    activeCollection === 'expenses'
      ? data?.collections.expenses.schema
      : data?.collections.users.schema;

  const handleCopy = () => {
    if (!currentDocs) return;
    navigator.clipboard.writeText(JSON.stringify(currentDocs, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
      <div className="bg-slate-900 text-slate-100 rounded-xl shadow-2xl border border-slate-800 max-w-4xl w-full max-h-[85vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-600/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
              <Database className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-white flex items-center gap-2">
                <span>MongoDB Collections Inspector</span>
                <span className="text-xs font-mono text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
                  database: expense_manager
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Live inspection of BSON documents and Mongoose Schema models
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={loadData}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              title="Refresh collections"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Collection Selector Tabs */}
        <div className="flex items-center justify-between px-6 py-2.5 border-b border-slate-800 bg-slate-900/80 text-xs">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveCollection('expenses')}
              className={`px-3 py-1.5 rounded-md font-mono transition-colors flex items-center gap-1.5 ${
                activeCollection === 'expenses'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileJson className="w-3.5 h-3.5" />
              <span>
                expenses ({data?.collections.expenses.count || 0} docs)
              </span>
            </button>
            <button
              onClick={() => setActiveCollection('users')}
              className={`px-3 py-1.5 rounded-md font-mono transition-colors flex items-center gap-1.5 ${
                activeCollection === 'users'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileJson className="w-3.5 h-3.5" />
              <span>users ({data?.collections.users.count || 0} docs)</span>
            </button>
          </div>

          <button
            onClick={handleCopy}
            className="inline-flex items-center gap-1 px-2.5 py-1 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded border border-slate-700 transition-colors"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy JSON</span>
              </>
            )}
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {/* Schema specs */}
          <div className="p-3.5 bg-slate-950 rounded-lg border border-slate-800">
            <div className="text-xs font-semibold text-slate-300 mb-2 font-mono">
              // Mongoose Schema Definition ({activeCollection})
            </div>
            <pre className="text-xs font-mono text-emerald-300/90 overflow-x-auto">
              {JSON.stringify(currentSchema, null, 2)}
            </pre>
          </div>

          {/* Documents JSON */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-mono">
                // Live Collection Documents (count: {currentDocs.length})
              </span>
              <span className="font-mono text-slate-500 text-[11px]">
                format: standard BSON / JSON
              </span>
            </div>
            <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 overflow-x-auto max-h-[350px]">
              <pre className="text-xs font-mono text-sky-300/90 leading-relaxed">
                {JSON.stringify(currentDocs, null, 2)}
              </pre>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between text-xs text-slate-400">
          <span>Demonstrating MongoDB CRUD Operations for Academic Viva</span>
          <button
            onClick={onClose}
            className="px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 text-white transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
