import React from 'react';
import {
  Search,
  Filter,
  Download,
  Trash2,
  Edit2,
  Calendar,
  Layers,
  ArrowUpDown,
  RotateCcw,
} from 'lucide-react';
import { Expense, ExpenseCategory, User } from '../types';
import { formatINR } from './StatsOverview';

interface ExpenseTableProps {
  expenses: Expense[];
  loading: boolean;
  currentUser: User | null;
  isAdminView: boolean;
  setIsAdminView: (val: boolean) => void;
  categories: ExpenseCategory[];
  filterCategory: string;
  setFilterCategory: (cat: string) => void;
  filterFrom: string;
  setFilterFrom: (val: string) => void;
  filterTo: string;
  setFilterTo: (val: string) => void;
  searchQuery: string;
  setSearchQuery: (val: string) => void;
  onEdit: (expense: Expense) => void;
  onDelete: (id: string) => void;
  onOpenAddExpense: () => void;
}

export const ExpenseTable: React.FC<ExpenseTableProps> = ({
  expenses,
  loading,
  currentUser,
  isAdminView,
  setIsAdminView,
  categories,
  filterCategory,
  setFilterCategory,
  filterFrom,
  setFilterFrom,
  filterTo,
  setFilterTo,
  searchQuery,
  setSearchQuery,
  onEdit,
  onDelete,
  onOpenAddExpense,
}) => {
  const isAdmin = currentUser?.role === 'admin';

  const resetFilters = () => {
    setFilterCategory('All');
    setFilterFrom('');
    setFilterTo('');
    setSearchQuery('');
  };

  const hasActiveFilters =
    filterCategory !== 'All' || filterFrom !== '' || filterTo !== '' || searchQuery !== '';

  const exportCSV = () => {
    if (expenses.length === 0) return;
    const headers = ['Date', 'Category', 'Amount (INR)', 'Description', 'User'];
    const rows = expenses.map((e) => [
      e.date,
      e.category,
      e.amount,
      `"${(e.description || '').replace(/"/g, '""')}"`,
      e.user ? e.user.name : '',
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `expenses_report_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredSum = expenses.reduce((sum, e) => sum + e.amount, 0);

  return (
    <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
      {/* Top Controls Toolbar */}
      <div className="p-4 sm:p-5 border-b border-slate-100 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-semibold text-slate-900">
              Expense Records Ledger
            </h2>
            <p className="text-xs text-slate-500">
              Stored in MongoDB · Showing {expenses.length} records · Filtered Sum:{' '}
              <span className="font-mono font-medium text-slate-900 tabular-nums">
                {formatINR(filteredSum)}
              </span>
            </p>
          </div>

          <div className="flex items-center gap-2">
            {isAdmin && (
              <label className="flex items-center gap-2 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 cursor-pointer hover:bg-slate-100 transition-colors">
                <input
                  type="checkbox"
                  checked={isAdminView}
                  onChange={(e) => setIsAdminView(e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-0 cursor-pointer"
                />
                <span className="font-medium">All Users Mode</span>
              </label>
            )}

            <button
              onClick={exportCSV}
              disabled={expenses.length === 0}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors disabled:opacity-40"
              title="Download CSV export"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        {/* Filters Strip */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
          {/* Search */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search description..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-600 bg-white"
            />
          </div>

          {/* Category Dropdown */}
          <div className="relative">
            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-600 bg-white text-slate-700"
            >
              <option value="All">All Categories</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* Date From */}
          <div className="relative">
            <input
              type="date"
              value={filterFrom}
              onChange={(e) => setFilterFrom(e.target.value)}
              placeholder="From Date"
              className="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-600 bg-white font-mono text-slate-700"
            />
          </div>

          {/* Date To & Reset */}
          <div className="flex items-center gap-2">
            <input
              type="date"
              value={filterTo}
              onChange={(e) => setFilterTo(e.target.value)}
              placeholder="To Date"
              className="w-full px-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-600 bg-white font-mono text-slate-700"
            />

            {hasActiveFilters && (
              <button
                onClick={resetFilters}
                title="Reset filters"
                className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors shrink-0"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Table Content */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
              <th className="py-3 px-4">Date</th>
              {isAdmin && isAdminView && <th className="py-3 px-4">User</th>}
              <th className="py-3 px-4">Category</th>
              <th className="py-3 px-4">Description</th>
              <th className="py-3 px-4 text-right">Amount (₹)</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-xs">
            {loading ? (
              <tr>
                <td
                  colSpan={isAdmin && isAdminView ? 6 : 5}
                  className="py-12 text-center text-slate-400"
                >
                  <div className="flex items-center justify-center gap-2">
                    <span className="w-4 h-4 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin" />
                    <span>Loading MongoDB documents...</span>
                  </div>
                </td>
              </tr>
            ) : expenses.length === 0 ? (
              <tr>
                <td
                  colSpan={isAdmin && isAdminView ? 6 : 5}
                  className="py-12 text-center text-slate-400"
                >
                  <div className="max-w-xs mx-auto space-y-2">
                    <p className="text-slate-600 font-medium">No expense records found</p>
                    <p className="text-slate-400 text-[11px]">
                      {hasActiveFilters
                        ? 'Try clearing your filter parameters to view all records.'
                        : 'Start tracking your spending by adding your first expense record.'}
                    </p>
                    {hasActiveFilters ? (
                      <button
                        onClick={resetFilters}
                        className="mt-2 px-3 py-1 text-xs text-indigo-600 font-medium hover:underline"
                      >
                        Clear Filters
                      </button>
                    ) : (
                      <button
                        onClick={onOpenAddExpense}
                        className="mt-2 px-3 py-1.5 text-xs text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors"
                      >
                        Add First Expense
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ) : (
              expenses.map((expense) => {
                const isOwner =
                  currentUser?.id &&
                  (expense.user?._id === currentUser.id ||
                    (expense as any).user === currentUser.id);
                const canManage = isOwner || isAdmin;

                return (
                  <tr
                    key={expense._id}
                    className="hover:bg-slate-50/80 transition-colors group"
                  >
                    {/* Date */}
                    <td className="py-3 px-4 whitespace-nowrap font-mono tabular-nums text-slate-700">
                      {expense.date}
                    </td>

                    {/* User Name (Admin view) */}
                    {isAdmin && isAdminView && (
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="font-medium text-slate-900">
                          {expense.user?.name || 'Unknown'}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          {expense.user?.email}
                        </div>
                      </td>
                    )}

                    {/* Category (unboxed clean text) */}
                    <td className="py-3 px-4 whitespace-nowrap font-medium text-slate-800">
                      {expense.category}
                    </td>

                    {/* Description */}
                    <td className="py-3 px-4 text-slate-600 max-w-xs truncate">
                      {expense.description || (
                        <span className="text-slate-300 italic">No notes</span>
                      )}
                    </td>

                    {/* Amount */}
                    <td className="py-3 px-4 text-right whitespace-nowrap font-mono tabular-nums font-semibold text-slate-900">
                      {formatINR(expense.amount)}
                    </td>

                    {/* Actions */}
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      {canManage ? (
                        <div className="inline-flex items-center gap-1">
                          <button
                            onClick={() => onEdit(expense)}
                            className="p-1 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded transition-colors"
                            title="Edit Record (PUT /api/expenses/:id)"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onDelete(expense._id)}
                            className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors"
                            title="Delete Record (DELETE /api/expenses/:id)"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <span className="text-[10px] text-slate-400 italic">
                          Read-only
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
