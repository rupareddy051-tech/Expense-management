import React, { useState } from 'react';
import { Lock, Mail, User as UserIcon, Shield, Sparkles } from 'lucide-react';
import { api, setStoredAuth } from '../services/api';
import { User } from '../types';

interface AuthModalProps {
  onSuccess: (user: User) => void;
  onOpenProjectInfo: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  onSuccess,
  onOpenProjectInfo,
}) => {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [name, setName] = useState<string>('');
  const [email, setEmail] = useState<string>('sreeja@mallareddy.ac.in');
  const [password, setPassword] = useState<string>('admin123');
  const [rolePreference, setRolePreference] = useState<'user' | 'admin'>('user');
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (mode === 'login') {
        const res = await api.login({ email, password });
        setStoredAuth(res.token, res.user);
        onSuccess(res.user);
      } else {
        const res = await api.register({
          name,
          email,
          password,
          rolePreference,
        });
        setStoredAuth(res.token, res.user);
        onSuccess(res.user);
      }
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  const setDemoAccount = (role: 'admin' | 'user') => {
    setMode('login');
    setError(null);
    if (role === 'admin') {
      setEmail('sreeja@mallareddy.ac.in');
      setPassword('admin123');
    } else {
      setEmail('rahul.varma@gmail.com');
      setPassword('user123');
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-4">
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xl max-w-md w-full p-6 sm:p-8 space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="w-12 h-12 bg-indigo-600 rounded-xl flex items-center justify-center text-white mx-auto shadow-md">
            <Lock className="w-6 h-6" />
          </div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">
            {mode === 'login' ? 'Sign In to ExpenseDesk' : 'Create an Account'}
          </h1>
          <p className="text-xs text-slate-500">
            MERN Stack Expense Management System
          </p>
        </div>

        {/* Quick Demo Credentials Buttons */}
        <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
          <div className="text-[11px] font-semibold text-slate-600 flex items-center justify-between">
            <span>Quick Demo Login:</span>
            <button
              type="button"
              onClick={onOpenProjectInfo}
              className="text-indigo-600 hover:underline font-normal text-[11px]"
            >
              View Project Specs
            </button>
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              type="button"
              onClick={() => setDemoAccount('admin')}
              className="px-3 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg text-left transition-colors"
            >
              <div className="font-semibold text-amber-800 text-[11px]">
                Demo Admin
              </div>
              <div className="text-[10px] text-slate-500 font-mono">
                Mantri Sreeja
              </div>
            </button>
            <button
              type="button"
              onClick={() => setDemoAccount('user')}
              className="px-3 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg text-left transition-colors"
            >
              <div className="font-semibold text-sky-800 text-[11px]">
                Demo User
              </div>
              <div className="text-[10px] text-slate-500 font-mono">
                Rahul Varma
              </div>
            </button>
          </div>
        </div>

        {/* Error Notification */}
        {error && (
          <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-700">
            {error}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'register' && (
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Full Name
              </label>
              <div className="relative">
                <UserIcon className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  required
                  placeholder="e.g. Sreeja Mantri"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="email"
                required
                placeholder="email@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 font-mono text-xs"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Password
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="password"
                required
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600"
              />
            </div>
          </div>

          {mode === 'register' && (
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Account Role (RBAC)
              </label>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setRolePreference('user')}
                  className={`p-2 rounded-lg border text-center transition-colors ${
                    rolePreference === 'user'
                      ? 'border-indigo-600 bg-indigo-50/50 text-indigo-700 font-semibold'
                      : 'border-slate-200 text-slate-600'
                  }`}
                >
                  Standard User
                </button>
                <button
                  type="button"
                  onClick={() => setRolePreference('admin')}
                  className={`p-2 rounded-lg border text-center transition-colors ${
                    rolePreference === 'admin'
                      ? 'border-indigo-600 bg-indigo-50/50 text-indigo-700 font-semibold'
                      : 'border-slate-200 text-slate-600'
                  }`}
                >
                  Administrator
                </button>
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-sm rounded-lg transition-colors shadow-xs disabled:opacity-50"
          >
            {loading
              ? 'Authenticating...'
              : mode === 'login'
              ? 'Sign In'
              : 'Create Account'}
          </button>
        </form>

        {/* Mode switcher */}
        <div className="text-center text-xs text-slate-500 pt-2 border-t border-slate-100">
          {mode === 'login' ? (
            <p>
              Don't have an account?{' '}
              <button
                type="button"
                onClick={() => {
                  setMode('register');
                  setError(null);
                }}
                className="text-indigo-600 font-semibold hover:underline"
              >
                Register here
              </button>
            </p>
          ) : (
            <p>
              Already registered?{' '}
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setError(null);
                }}
                className="text-indigo-600 font-semibold hover:underline"
              >
                Sign in here
              </button>
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
