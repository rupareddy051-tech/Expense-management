import React from 'react';
import { ExpenseStats, ExpenseCategory } from '../types';

interface StatsOverviewProps {
  stats: ExpenseStats | null;
  loading: boolean;
  isAdminView?: boolean;
}

export const formatINR = (val: number): string => {
  return '₹' + Number(val || 0).toLocaleString('en-IN', {
    maximumFractionDigits: 2,
    minimumFractionDigits: 0,
  });
};

const categoryColorMap: Record<ExpenseCategory | string, string> = {
  Food: 'bg-amber-500',
  Travel: 'bg-sky-500',
  Shopping: 'bg-pink-500',
  Bills: 'bg-emerald-500',
  Education: 'bg-indigo-600',
  Health: 'bg-rose-500',
  Entertainment: 'bg-purple-500',
  Other: 'bg-slate-500',
};

export const StatsOverview: React.FC<StatsOverviewProps> = ({
  stats,
  loading,
  isAdminView,
}) => {
  if (loading && !stats) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {[1, 2, 3, 4].map((i) => (
          <div
            key={i}
            className="p-4 bg-white border border-slate-200 rounded-xl animate-pulse h-24"
          />
        ))}
      </div>
    );
  }

  const total = stats?.totalSpent || 0;
  const thisMonth = stats?.thisMonthSpent || 0;
  const count = stats?.transactionCount || 0;
  const topCat = stats?.topCategory || 'N/A';
  const categories = stats?.categories || [];
  const maxCategorySpend = categories.length > 0 ? categories[0].amount : 1;

  return (
    <div className="space-y-6 mb-8">
      {/* 4-KPI Metric Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-xs">
          <div className="text-xs font-medium text-slate-500 mb-1">
            {isAdminView ? 'All Users Total Spent' : 'Total Spent'}
          </div>
          <div className="text-2xl font-bold text-slate-900 font-mono tabular-nums">
            {formatINR(total)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Across {count} recorded transactions
          </div>
        </div>

        <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-xs">
          <div className="text-xs font-medium text-slate-500 mb-1">
            This Month
          </div>
          <div className="text-2xl font-bold text-indigo-600 font-mono tabular-nums">
            {formatINR(thisMonth)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {total > 0 ? `${((thisMonth / total) * 100).toFixed(1)}% of total spend` : 'Current calendar month'}
          </div>
        </div>

        <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-xs">
          <div className="text-xs font-medium text-slate-500 mb-1">
            Total Records
          </div>
          <div className="text-2xl font-bold text-slate-900 font-mono tabular-nums">
            {count}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Stored in MongoDB collection
          </div>
        </div>

        <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-xs">
          <div className="text-xs font-medium text-slate-500 mb-1">
            Primary Expenditure
          </div>
          <div className="text-2xl font-bold text-slate-900 truncate">
            {topCat}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {categories.length > 0
              ? `${formatINR(categories[0].amount)} (${categories[0].percentage.toFixed(0)}%)`
              : 'No categorized data'}
          </div>
        </div>
      </div>

      {/* Category Expenditure Distribution Breakdown */}
      <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">
              Category Spending Breakdown
            </h3>
            <p className="text-xs text-slate-500">
              Aggregated via MongoDB pipeline ($group by category, $sum amount)
            </p>
          </div>
          <span className="text-xs font-mono tabular-nums text-slate-500">
            {categories.length} Categories Active
          </span>
        </div>

        {categories.length === 0 ? (
          <div className="py-6 text-center text-xs text-slate-400">
            No expenses logged yet. Add an expense above to view spending patterns.
          </div>
        ) : (
          <div className="space-y-3">
            {categories.map((c) => {
              const barWidth = Math.max(
                4,
                Math.round((c.amount / maxCategorySpend) * 100)
              );
              const colorClass =
                categoryColorMap[c.category] || 'bg-indigo-600';

              return (
                <div key={c.category} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-slate-700">
                      {c.category}
                    </span>
                    <div className="flex items-center gap-3">
                      <span className="font-mono tabular-nums text-slate-500 text-[11px]">
                        {c.percentage.toFixed(1)}%
                      </span>
                      <span className="font-mono tabular-nums font-semibold text-slate-900">
                        {formatINR(c.amount)}
                      </span>
                    </div>
                  </div>
                  <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${colorClass} transition-all duration-300 rounded-full`}
                      style={{ width: `${barWidth}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
