import React from 'react';
import {
  TrendingUp,
  PieChart,
  Calendar,
  Layers,
  ArrowUpRight,
  CreditCard,
} from 'lucide-react';
import { ExpenseStats, ExpenseCategory } from '../types';
import { formatINR } from './StatsOverview';

interface AnalyticsViewProps {
  stats: ExpenseStats | null;
  loading: boolean;
  isAdminView?: boolean;
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({
  stats,
  loading,
  isAdminView,
}) => {
  if (loading && !stats) {
    return (
      <div className="p-8 text-center text-slate-400">
        Computing MongoDB aggregation pipelines...
      </div>
    );
  }

  const categories = stats?.categories || [];
  const monthly = Object.entries(stats?.monthlyTotals || {}).sort((a, b) =>
    b[0].localeCompare(a[0])
  );
  const total = stats?.totalSpent || 0;
  const count = stats?.transactionCount || 0;
  const avg = count > 0 ? total / count : 0;

  const maxMonthVal = monthly.length > 0 ? Math.max(...monthly.map((m) => m[1])) : 1;

  return (
    <div className="space-y-6">
      {/* Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-xs">
          <div className="text-xs text-slate-500 mb-1">Total Recorded Spend</div>
          <div className="text-2xl font-bold text-slate-900 font-mono tabular-nums">
            {formatINR(total)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {isAdminView ? 'Across all system users' : 'Personal ledger total'}
          </div>
        </div>

        <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-xs">
          <div className="text-xs text-slate-500 mb-1">Average per Transaction</div>
          <div className="text-2xl font-bold text-indigo-600 font-mono tabular-nums">
            {formatINR(avg)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Calculated over {count} entries
          </div>
        </div>

        <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-xs">
          <div className="text-xs text-slate-500 mb-1">Lead Spend Category</div>
          <div className="text-2xl font-bold text-slate-900 truncate">
            {stats?.topCategory || 'N/A'}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Largest cumulative share
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Category Breakdown Table */}
        <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-xs space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">
              Categorical Breakdown &amp; Share
            </h3>
            <p className="text-xs text-slate-500">
              Aggregated using MongoDB aggregation pipeline
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-400 font-medium">
                  <th className="pb-2">Category</th>
                  <th className="pb-2 text-right">Amount (₹)</th>
                  <th className="pb-2 text-right">Share (%)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {categories.length === 0 ? (
                  <tr>
                    <td colSpan={3} className="py-6 text-center text-slate-400">
                      No expenses logged
                    </td>
                  </tr>
                ) : (
                  categories.map((c) => (
                    <tr key={c.category} className="hover:bg-slate-50/60">
                      <td className="py-2.5 font-medium text-slate-800">
                        {c.category}
                      </td>
                      <td className="py-2.5 text-right font-mono tabular-nums text-slate-900 font-semibold">
                        {formatINR(c.amount)}
                      </td>
                      <td className="py-2.5 text-right font-mono tabular-nums text-slate-500">
                        {c.percentage.toFixed(1)}%
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Monthly Trend Timeline */}
        <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-xs space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">
              Monthly Expenditure Trend
            </h3>
            <p className="text-xs text-slate-500">
              Expenditures grouped by calendar month
            </p>
          </div>

          <div className="space-y-3 pt-2">
            {monthly.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-400">
                No monthly transactions recorded yet
              </div>
            ) : (
              monthly.map(([m, amt]) => {
                const widthPercent = Math.max(8, Math.round((amt / maxMonthVal) * 100));
                return (
                  <div key={m} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-mono text-slate-700 font-medium">
                        {m}
                      </span>
                      <span className="font-mono tabular-nums font-semibold text-slate-900">
                        {formatINR(amt)}
                      </span>
                    </div>
                    <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-indigo-600 rounded-full transition-all duration-300"
                        style={{ width: `${widthPercent}%` }}
                      />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
