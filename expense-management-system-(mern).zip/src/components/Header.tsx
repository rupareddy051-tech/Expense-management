import React from 'react';
import {
  WalletCards,
  Database,
  Info,
  LogOut,
  UserCheck,
  Shield,
  Plus,
  FileCode,
} from 'lucide-react';
import { User } from '../types';

interface HeaderProps {
  user: User | null;
  activeTab: 'expenses' | 'analytics' | 'admin';
  setActiveTab: (tab: 'expenses' | 'analytics' | 'admin') => void;
  onOpenAddExpense: () => void;
  onOpenMongoInspector: () => void;
  onOpenProjectInfo: (tab?: 'overview' | 'api' | 'architecture' | 'source_code') => void;
  onLogout: () => void;
  onQuickSwitchUser: (role: 'admin' | 'user') => void;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  activeTab,
  setActiveTab,
  onOpenAddExpense,
  onOpenMongoInspector,
  onOpenProjectInfo,
  onLogout,
  onQuickSwitchUser,
}) => {
  return (
    <header className="border-b border-slate-200 bg-white sticky top-0 z-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-9 h-9 rounded-lg bg-indigo-600 flex items-center justify-center text-white shadow-sm">
              <WalletCards className="w-5 h-5" />
            </div>
            <div>
              <span className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap">
                ExpenseDesk
              </span>
              <span className="hidden sm:inline-block ml-2 text-xs text-slate-500 font-mono">
                MERN v1.0
              </span>
            </div>
          </div>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 text-sm font-medium text-slate-600">
            <button
              onClick={() => setActiveTab('expenses')}
              className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
                activeTab === 'expenses'
                  ? 'bg-slate-100 text-slate-900 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Expenses
            </button>
            <button
              onClick={() => setActiveTab('analytics')}
              className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
                activeTab === 'analytics'
                  ? 'bg-slate-100 text-slate-900 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Analytics
            </button>
            {user?.role === 'admin' && (
              <button
                onClick={() => setActiveTab('admin')}
                className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap ${
                  activeTab === 'admin'
                    ? 'bg-slate-100 text-slate-900 font-semibold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                Admin Panel
              </button>
            )}
            <button
              onClick={onOpenMongoInspector}
              className="px-3 py-1.5 rounded-md text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-colors whitespace-nowrap flex items-center gap-1.5"
            >
              <Database className="w-3.5 h-3.5 text-emerald-600" />
              <span>MongoDB Inspector</span>
            </button>
            <button
              onClick={() => onOpenProjectInfo('source_code')}
              className="px-3 py-1.5 rounded-md text-amber-700 bg-amber-50 hover:bg-amber-100 transition-colors whitespace-nowrap flex items-center gap-1.5 font-medium"
            >
              <FileCode className="w-3.5 h-3.5 text-amber-600" />
              <span>JS Code (server.js)</span>
            </button>
            <button
              onClick={() => onOpenProjectInfo('overview')}
              className="px-3 py-1.5 rounded-md text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-colors whitespace-nowrap flex items-center gap-1.5"
            >
              <Info className="w-3.5 h-3.5 text-indigo-600" />
              <span>Project & Viva Info</span>
            </button>
          </nav>

          {/* Zone 3: Primary Action & User Session */}
          <div className="flex items-center gap-3 shrink-0">
            {user ? (
              <>
                <button
                  onClick={onOpenAddExpense}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors shadow-sm whitespace-nowrap"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Expense</span>
                </button>

                {/* Quick Account Switcher for Evaluators */}
                <div className="hidden lg:flex items-center border border-slate-200 rounded-lg p-0.5 bg-slate-50 text-xs">
                  <button
                    onClick={() => onQuickSwitchUser('admin')}
                    title="Switch to Admin account (Mantri Sreeja)"
                    className={`px-2 py-1 rounded transition-colors ${
                      user.role === 'admin'
                        ? 'bg-white text-indigo-700 font-semibold shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Demo Admin
                  </button>
                  <button
                    onClick={() => onQuickSwitchUser('user')}
                    title="Switch to User account (Rahul Varma)"
                    className={`px-2 py-1 rounded transition-colors ${
                      user.role === 'user'
                        ? 'bg-white text-indigo-700 font-semibold shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Demo User
                  </button>
                </div>

                {/* User Info Label (Unboxed, clean metadata) */}
                <div className="hidden sm:flex items-center text-xs text-slate-600">
                  <span className="font-medium text-slate-900">{user.name}</span>
                  <span className="mx-1.5 text-slate-300">·</span>
                  <span className="font-mono text-slate-500 uppercase tracking-wider text-[10px]">
                    {user.role}
                  </span>
                </div>

                <button
                  onClick={onLogout}
                  title="Logout"
                  className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-md transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </>
            ) : (
              <button
                onClick={() => onOpenProjectInfo('overview')}
                className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap"
              >
                Project Details
              </button>
            )}
          </div>
        </div>

        {/* Mobile Subnav */}
        <div className="md:hidden flex items-center justify-between py-2 border-t border-slate-100 overflow-x-auto text-xs gap-2">
          <div className="flex items-center gap-1">
            <button
              onClick={() => setActiveTab('expenses')}
              className={`px-2.5 py-1 rounded ${
                activeTab === 'expenses'
                  ? 'bg-slate-200 font-semibold text-slate-900'
                  : 'text-slate-600'
              }`}
            >
              Expenses
            </button>
            <button
              onClick={() => setActiveTab('analytics')}
              className={`px-2.5 py-1 rounded ${
                activeTab === 'analytics'
                  ? 'bg-slate-200 font-semibold text-slate-900'
                  : 'text-slate-600'
              }`}
            >
              Analytics
            </button>
            {user?.role === 'admin' && (
              <button
                onClick={() => setActiveTab('admin')}
                className={`px-2.5 py-1 rounded ${
                  activeTab === 'admin'
                    ? 'bg-slate-200 font-semibold text-slate-900'
                    : 'text-slate-600'
                }`}
              >
                Admin
              </button>
            )}
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={onOpenMongoInspector}
              className="px-2 py-1 text-emerald-700 hover:bg-emerald-50 rounded"
            >
              DB Inspect
            </button>
            <button
              onClick={() => onOpenProjectInfo('overview')}
              className="px-2 py-1 text-indigo-700 hover:bg-indigo-50 rounded"
            >
              Info
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
