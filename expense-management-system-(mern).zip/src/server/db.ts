import bcrypt from 'bcryptjs';
import fs from 'fs';
import path from 'path';

export const CATEGORIES = [
  'Food',
  'Travel',
  'Shopping',
  'Bills',
  'Education',
  'Health',
  'Entertainment',
  'Other',
] as const;

export type Category = (typeof CATEGORIES)[number];

export interface IUser {
  _id: string;
  name: string;
  email: string;
  password: string;
  role: 'user' | 'admin';
  createdAt: string;
  updatedAt: string;
}

export interface IExpense {
  _id: string;
  user: string; // User ID
  date: string; // ISO date string (YYYY-MM-DD)
  category: Category;
  amount: number;
  description: string;
  createdAt: string;
  updatedAt: string;
}

export interface IPopulatedExpense extends Omit<IExpense, 'user'> {
  user: {
    _id: string;
    name: string;
    email: string;
  } | null;
}

// Generate MongoDB-compatible 24-char hex ObjectId
export function generateObjectId(): string {
  const timestamp = Math.floor(Date.now() / 1000).toString(16).padStart(8, '0');
  const random = Array.from({ length: 16 }, () =>
    Math.floor(Math.random() * 16).toString(16)
  ).join('');
  return timestamp + random;
}

const DATA_DIR = path.resolve(process.cwd(), '.data');
const DATA_FILE = path.join(DATA_DIR, 'mongodb_store.json');

interface StoreData {
  users: IUser[];
  expenses: IExpense[];
}

let memoryStore: StoreData = {
  users: [],
  expenses: [],
};

function ensureDirSync(dir: string) {
  if (!fs.existsSync(dir)) {
    try {
      fs.mkdirSync(dir, { recursive: true });
    } catch {
      // directory creation handled
    }
  }
}

function saveStore() {
  try {
    ensureDirSync(DATA_DIR);
    fs.writeFileSync(DATA_FILE, JSON.stringify(memoryStore, null, 2), 'utf8');
  } catch (err) {
    console.warn('[MongoDB Store] Unable to write to disk, using memory:', err);
  }
}

function loadStore(): boolean {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const data = fs.readFileSync(DATA_FILE, 'utf8');
      const parsed = JSON.parse(data);
      if (Array.isArray(parsed.users) && Array.isArray(parsed.expenses)) {
        memoryStore = parsed;
        return true;
      }
    }
  } catch (err) {
    console.warn('[MongoDB Store] Error reading persistence file:', err);
  }
  return false;
}

export async function initDatabase(forceReset = false) {
  if (!forceReset && loadStore() && memoryStore.users.length > 0) {
    console.log(`[MongoDB Engine] Loaded existing database: ${memoryStore.users.length} users, ${memoryStore.expenses.length} expenses`);
    return;
  }

  console.log('[MongoDB Engine] Initializing database with seed dataset...');

  const now = new Date().toISOString();
  const hashedPasswordAdmin = await bcrypt.hash('admin123', 10);
  const hashedPasswordUser1 = await bcrypt.hash('user123', 10);
  const hashedPasswordUser2 = await bcrypt.hash('user123', 10);

  const adminId = '654a1b2c3d4e5f6a7b8c9d01';
  const user1Id = '654a1b2c3d4e5f6a7b8c9d02';
  const user2Id = '654a1b2c3d4e5f6a7b8c9d03';

  const users: IUser[] = [
    {
      _id: adminId,
      name: 'Mantri Sreeja (Admin)',
      email: 'sreeja@mallareddy.ac.in',
      password: hashedPasswordAdmin,
      role: 'admin',
      createdAt: new Date(Date.now() - 30 * 86400000).toISOString(),
      updatedAt: now,
    },
    {
      _id: user1Id,
      name: 'Rahul Varma',
      email: 'rahul.varma@gmail.com',
      password: hashedPasswordUser1,
      role: 'user',
      createdAt: new Date(Date.now() - 25 * 86400000).toISOString(),
      updatedAt: now,
    },
    {
      _id: user2Id,
      name: 'Priya Sharma',
      email: 'priya.sharma@gmail.com',
      password: hashedPasswordUser2,
      role: 'user',
      createdAt: new Date(Date.now() - 20 * 86400000).toISOString(),
      updatedAt: now,
    },
  ];

  // Current year & month for realistic demonstration
  const today = new Date();
  const getPastDateStr = (daysAgo: number) => {
    const d = new Date(today.getTime() - daysAgo * 86400000);
    return d.toISOString().slice(0, 10);
  };

  const expenses: IExpense[] = [
    // Sreeja's expenses (Admin)
    {
      _id: generateObjectId(),
      user: adminId,
      date: getPastDateStr(1),
      category: 'Education',
      amount: 4500,
      description: 'MERN Stack Cloud Certification & Course Material',
      createdAt: new Date(Date.now() - 1 * 86400000).toISOString(),
      updatedAt: new Date(Date.now() - 1 * 86400000).toISOString(),
    },
    {
      _id: generateObjectId(),
      user: adminId,
      date: getPastDateStr(2),
      category: 'Food',
      amount: 380,
      description: 'Campus cafeteria lunch with project team',
      createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
      updatedAt: new Date(Date.now() - 2 * 86400000).toISOString(),
    },
    {
      _id: generateObjectId(),
      user: adminId,
      date: getPastDateStr(4),
      category: 'Bills',
      amount: 1199,
      description: 'Fiber Broadband High-Speed Internet Bill',
      createdAt: new Date(Date.now() - 4 * 86400000).toISOString(),
      updatedAt: new Date(Date.now() - 4 * 86400000).toISOString(),
    },
    {
      _id: generateObjectId(),
      user: adminId,
      date: getPastDateStr(7),
      category: 'Travel',
      amount: 850,
      description: 'Hyderabad Metro Smart Card Monthly Recharge',
      createdAt: new Date(Date.now() - 7 * 86400000).toISOString(),
      updatedAt: new Date(Date.now() - 7 * 86400000).toISOString(),
    },
    {
      _id: generateObjectId(),
      user: adminId,
      date: getPastDateStr(11),
      category: 'Shopping',
      amount: 2490,
      description: 'Mechanical keyboard & ergonomic mouse',
      createdAt: new Date(Date.now() - 11 * 86400000).toISOString(),
      updatedAt: new Date(Date.now() - 11 * 86400000).toISOString(),
    },
    {
      _id: generateObjectId(),
      user: adminId,
      date: getPastDateStr(15),
      category: 'Health',
      amount: 650,
      description: 'Annual medical checkup & multivitamins',
      createdAt: new Date(Date.now() - 15 * 86400000).toISOString(),
      updatedAt: new Date(Date.now() - 15 * 86400000).toISOString(),
    },
    {
      _id: generateObjectId(),
      user: adminId,
      date: getPastDateStr(18),
      category: 'Entertainment',
      amount: 799,
      description: 'Streaming & learning platform subscription',
      createdAt: new Date(Date.now() - 18 * 86400000).toISOString(),
      updatedAt: new Date(Date.now() - 18 * 86400000).toISOString(),
    },

    // Rahul's expenses (User)
    {
      _id: generateObjectId(),
      user: user1Id,
      date: getPastDateStr(3),
      category: 'Food',
      amount: 520,
      description: 'Dinner with college friends at Bawarchi',
      createdAt: new Date(Date.now() - 3 * 86400000).toISOString(),
      updatedAt: new Date(Date.now() - 3 * 86400000).toISOString(),
    },
    {
      _id: generateObjectId(),
      user: user1Id,
      date: getPastDateStr(6),
      category: 'Travel',
      amount: 450,
      description: 'Cab fare to tech conference venue',
      createdAt: new Date(Date.now() - 6 * 86400000).toISOString(),
      updatedAt: new Date(Date.now() - 6 * 86400000).toISOString(),
    },
    {
      _id: generateObjectId(),
      user: user1Id,
      date: getPastDateStr(12),
      category: 'Education',
      amount: 2200,
      description: 'Reference textbooks for Database Systems',
      createdAt: new Date(Date.now() - 12 * 86400000).toISOString(),
      updatedAt: new Date(Date.now() - 12 * 86400000).toISOString(),
    },

    // Priya's expenses (User)
    {
      _id: generateObjectId(),
      user: user2Id,
      date: getPastDateStr(2),
      category: 'Shopping',
      amount: 1850,
      description: 'Formal attire for campus placement drive',
      createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
      updatedAt: new Date(Date.now() - 2 * 86400000).toISOString(),
    },
    {
      _id: generateObjectId(),
      user: user2Id,
      date: getPastDateStr(8),
      category: 'Food',
      amount: 340,
      description: 'Snacks and coffee at library cafe',
      createdAt: new Date(Date.now() - 8 * 86400000).toISOString(),
      updatedAt: new Date(Date.now() - 8 * 86400000).toISOString(),
    },
  ];

  memoryStore = { users, expenses };
  saveStore();
}

// User methods
export const UserModel = {
  async count(): Promise<number> {
    return memoryStore.users.length;
  },

  async find(): Promise<IUser[]> {
    return [...memoryStore.users];
  },

  async findById(id: string): Promise<IUser | null> {
    const user = memoryStore.users.find((u) => u._id === id);
    return user ? { ...user } : null;
  },

  async findByEmail(email: string): Promise<IUser | null> {
    const target = email.trim().toLowerCase();
    const user = memoryStore.users.find(
      (u) => u.email.trim().toLowerCase() === target
    );
    return user ? { ...user } : null;
  },

  async create(data: {
    name: string;
    email: string;
    password: string;
    role: 'user' | 'admin';
  }): Promise<IUser> {
    const now = new Date().toISOString();
    const newUser: IUser = {
      _id: generateObjectId(),
      name: data.name.trim(),
      email: data.email.trim().toLowerCase(),
      password: data.password,
      role: data.role,
      createdAt: now,
      updatedAt: now,
    };
    memoryStore.users.push(newUser);
    saveStore();
    return { ...newUser };
  },

  async deleteById(id: string): Promise<boolean> {
    const idx = memoryStore.users.findIndex((u) => u._id === id);
    if (idx !== -1) {
      memoryStore.users.splice(idx, 1);
      saveStore();
      return true;
    }
    return false;
  },
};

// Expense methods
export const ExpenseModel = {
  async find(filter: {
    user?: string;
    category?: string;
    from?: string;
    to?: string;
    search?: string;
  }): Promise<IPopulatedExpense[]> {
    let result = [...memoryStore.expenses];

    if (filter.user) {
      result = result.filter((e) => e.user === filter.user);
    }

    if (filter.category && filter.category !== 'All') {
      result = result.filter((e) => e.category === filter.category);
    }

    if (filter.from) {
      result = result.filter((e) => e.date >= filter.from!);
    }

    if (filter.to) {
      result = result.filter((e) => e.date <= filter.to!);
    }

    if (filter.search) {
      const q = filter.search.toLowerCase();
      result = result.filter((e) =>
        e.description.toLowerCase().includes(q) ||
        e.category.toLowerCase().includes(q)
      );
    }

    // Sort by date DESC, then createdAt DESC
    result.sort((a, b) => {
      if (a.date !== b.date) {
        return b.date.localeCompare(a.date);
      }
      return b.createdAt.localeCompare(a.createdAt);
    });

    // Populate user
    const usersMap = new Map(memoryStore.users.map((u) => [u._id, u]));

    return result.map((e) => {
      const u = usersMap.get(e.user);
      return {
        _id: e._id,
        date: e.date,
        category: e.category,
        amount: e.amount,
        description: e.description,
        createdAt: e.createdAt,
        updatedAt: e.updatedAt,
        user: u ? { _id: u._id, name: u.name, email: u.email } : null,
      };
    });
  },

  async findById(id: string): Promise<IExpense | null> {
    const exp = memoryStore.expenses.find((e) => e._id === id);
    return exp ? { ...exp } : null;
  },

  async create(data: {
    user: string;
    date: string;
    category: Category;
    amount: number;
    description: string;
  }): Promise<IExpense> {
    const now = new Date().toISOString();
    const newExpense: IExpense = {
      _id: generateObjectId(),
      user: data.user,
      date: data.date,
      category: data.category,
      amount: Number(data.amount),
      description: data.description.trim(),
      createdAt: now,
      updatedAt: now,
    };
    memoryStore.expenses.push(newExpense);
    saveStore();
    return { ...newExpense };
  },

  async updateById(
    id: string,
    data: {
      date: string;
      category: Category;
      amount: number;
      description: string;
    }
  ): Promise<IExpense | null> {
    const exp = memoryStore.expenses.find((e) => e._id === id);
    if (!exp) return null;

    exp.date = data.date;
    exp.category = data.category;
    exp.amount = Number(data.amount);
    exp.description = data.description.trim();
    exp.updatedAt = new Date().toISOString();

    saveStore();
    return { ...exp };
  },

  async deleteById(id: string): Promise<boolean> {
    const idx = memoryStore.expenses.findIndex((e) => e._id === id);
    if (idx !== -1) {
      memoryStore.expenses.splice(idx, 1);
      saveStore();
      return true;
    }
    return false;
  },

  async deleteManyByUser(userId: string): Promise<number> {
    const initialLen = memoryStore.expenses.length;
    memoryStore.expenses = memoryStore.expenses.filter((e) => e.user !== userId);
    saveStore();
    return initialLen - memoryStore.expenses.length;
  },

  // Aggregation simulating Mongoose aggregate([ { $group: ... } ])
  async aggregateUserTotals() {
    const totals: Record<string, { total: number; count: number }> = {};
    for (const exp of memoryStore.expenses) {
      if (!totals[exp.user]) {
        totals[exp.user] = { total: 0, count: 0 };
      }
      totals[exp.user].total += exp.amount;
      totals[exp.user].count += 1;
    }
    return totals;
  },

  // Aggregation for category breakdown & metrics
  async aggregateAnalytics(userId?: string) {
    let list = memoryStore.expenses;
    if (userId) {
      list = list.filter((e) => e.user === userId);
    }

    const currentMonthPrefix = new Date().toISOString().slice(0, 7);
    let totalSpent = 0;
    let thisMonthSpent = 0;
    const categoryTotals: Record<string, number> = {};
    const monthlyTotals: Record<string, number> = {};

    for (const exp of list) {
      totalSpent += exp.amount;
      if (exp.date.startsWith(currentMonthPrefix)) {
        thisMonthSpent += exp.amount;
      }
      categoryTotals[exp.category] = (categoryTotals[exp.category] || 0) + exp.amount;
      const monthKey = exp.date.slice(0, 7);
      monthlyTotals[monthKey] = (monthlyTotals[monthKey] || 0) + exp.amount;
    }

    const sortedCategories = Object.entries(categoryTotals)
      .map(([category, amount]) => ({
        category,
        amount,
        percentage: totalSpent > 0 ? (amount / totalSpent) * 100 : 0,
      }))
      .sort((a, b) => b.amount - a.amount);

    return {
      totalSpent,
      thisMonthSpent,
      transactionCount: list.length,
      topCategory: sortedCategories[0]?.category || 'N/A',
      categories: sortedCategories,
      monthlyTotals,
    };
  },
};

export function getRawCollections() {
  return {
    database: 'expense_manager',
    collections: {
      users: {
        count: memoryStore.users.length,
        schema: {
          _id: 'ObjectId',
          name: 'String (required, trim)',
          email: 'String (required, unique, lowercase)',
          password: 'String (hashed via bcrypt)',
          role: "String (enum: ['user', 'admin'])",
          timestamps: 'Boolean (createdAt, updatedAt)',
        },
        documents: memoryStore.users.map((u) => ({
          _id: u._id,
          name: u.name,
          email: u.email,
          role: u.role,
          createdAt: u.createdAt,
          updatedAt: u.updatedAt,
        })),
      },
      expenses: {
        count: memoryStore.expenses.length,
        schema: {
          _id: 'ObjectId',
          user: 'ObjectId (ref: User, required)',
          date: 'Date (required)',
          category: 'String (enum: 8 categories, required)',
          amount: 'Number (required, min: 0.01)',
          description: 'String (default: "", trim)',
          timestamps: 'Boolean (createdAt, updatedAt)',
        },
        documents: memoryStore.expenses,
      },
    },
  };
}
