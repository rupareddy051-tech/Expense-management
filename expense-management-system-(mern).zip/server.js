/*
 * ============================================================
 *  EXPENSE MANAGEMENT SYSTEM  (MERN Stack in Pure JavaScript)
 *  Developer & Presenter : Mantri Sreeja
 *  College               : Malla Reddy Vishwavidyapeeth Technical Campus
 *  Problem Statement     : 49. Expense Management
 * ============================================================
 *  M = MongoDB (Mongoose Models & Aggregations)
 *  E = Express.js (REST API Routes & JWT Middlewares)
 *  R = React.js (Component-driven User Interface)
 *  N = Node.js (JavaScript Runtime Environment)
 *
 *  Run:   npm install
 *         node server.js
 *  Open:  http://localhost:3000 (or http://localhost:5000)
 * ============================================================
 */

const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'sreeja_expense_manager_secret_key_2026';
const CATEGORIES = [
  'Food',
  'Travel',
  'Shopping',
  'Bills',
  'Education',
  'Health',
  'Entertainment',
  'Other'
];

/* ============================================================
 *  1. DATA LAYER (MongoDB / Mongoose Compatible Datastore)
 * ============================================================
 */
function generateObjectId() {
  const ts = Math.floor(Date.now() / 1000).toString(16).padStart(8, '0');
  const rand = Array.from({ length: 16 }, () =>
    Math.floor(Math.random() * 16).toString(16)
  ).join('');
  return ts + rand;
}

const DATA_FILE = path.join(__dirname, '.data', 'mongodb_store.json');

let database = {
  users: [],
  expenses: []
};

function saveDb() {
  try {
    const dir = path.dirname(DATA_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(DATA_FILE, JSON.stringify(database, null, 2), 'utf8');
  } catch (e) {
    console.warn('[Storage] Notice:', e.message);
  }
}

function loadDb() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const content = fs.readFileSync(DATA_FILE, 'utf8');
      const parsed = JSON.parse(content);
      if (Array.isArray(parsed.users) && Array.isArray(parsed.expenses)) {
        database = parsed;
        return true;
      }
    }
  } catch (e) {
    console.warn('[Storage] Notice:', e.message);
  }
  return false;
}

// Seed Initial Demonstration Data
async function initSeedData() {
  if (loadDb() && database.users.length > 0) return;

  const adminPass = await bcrypt.hash('admin123', 10);
  const userPass = await bcrypt.hash('user123', 10);

  const adminId = '654a1b2c3d4e5f6a7b8c9d01';
  const userId = '654a1b2c3d4e5f6a7b8c9d02';

  database.users = [
    {
      _id: adminId,
      name: 'Mantri Sreeja (Admin)',
      email: 'sreeja@mallareddy.ac.in',
      password: adminPass,
      role: 'admin',
      createdAt: new Date().toISOString()
    },
    {
      _id: userId,
      name: 'Rahul Varma',
      email: 'rahul.varma@gmail.com',
      password: userPass,
      role: 'user',
      createdAt: new Date().toISOString()
    }
  ];

  const now = new Date();
  const dateStr = (offsetDays) =>
    new Date(now.getTime() - offsetDays * 86400000).toISOString().slice(0, 10);

  database.expenses = [
    {
      _id: generateObjectId(),
      user: adminId,
      date: dateStr(1),
      category: 'Education',
      amount: 4500,
      description: 'MERN Stack Cloud Certification & Project Materials',
      createdAt: new Date().toISOString()
    },
    {
      _id: generateObjectId(),
      user: adminId,
      date: dateStr(2),
      category: 'Food',
      amount: 380,
      description: 'Campus cafeteria lunch with project team',
      createdAt: new Date().toISOString()
    },
    {
      _id: generateObjectId(),
      user: adminId,
      date: dateStr(4),
      category: 'Bills',
      amount: 1199,
      description: 'High-speed broadband internet subscription',
      createdAt: new Date().toISOString()
    },
    {
      _id: generateObjectId(),
      user: adminId,
      date: dateStr(7),
      category: 'Travel',
      amount: 850,
      description: 'Hyderabad Metro Monthly Pass',
      createdAt: new Date().toISOString()
    },
    {
      _id: generateObjectId(),
      user: userId,
      date: dateStr(3),
      category: 'Food',
      amount: 520,
      description: 'Dinner with college friends',
      createdAt: new Date().toISOString()
    }
  ];

  saveDb();
}

/* ============================================================
 *  2. EXPRESS APP & MIDDLEWARE SETUP
 * ============================================================
 */
const app = express();
app.use(cors());
app.use(express.json());

// Token Generation
function signToken(u) {
  return jwt.sign(
    { id: u._id, role: u.role, name: u.name, email: u.email },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
}

// Authentication Middleware
function auth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ message: 'Authentication required. Please login.' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch (e) {
    res.status(401).json({ message: 'Session expired. Please log in again.' });
  }
}

// Role-Based Access Control (Admin Only) Middleware
function adminOnly(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Access denied: Admin privileges required.' });
  }
  next();
}

// Input Validation for Expense
function validateExpense(b) {
  if (!b.date || isNaN(new Date(b.date).getTime())) return 'Valid date in format YYYY-MM-DD is required';
  if (!CATEGORIES.includes(b.category)) return 'Invalid category selected';
  const amt = Number(b.amount);
  if (isNaN(amt) || amt <= 0) return 'Amount must be greater than 0';
  return null;
}

/* ============================================================
 *  3. RESTFUL API ROUTES (JavaScript / Express.js)
 * ============================================================
 */

// POST /api/auth/register
app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password, rolePreference } = req.body;
    if (!name || !email || !password) return res.status(400).json({ message: 'All fields are required' });
    if (password.length < 6) return res.status(400).json({ message: 'Password must be at least 6 characters' });

    const lowerEmail = email.trim().toLowerCase();
    const existing = database.users.find(u => u.email === lowerEmail);
    if (existing) return res.status(400).json({ message: 'Email already registered' });

    const isFirst = database.users.length === 0;
    const role = isFirst ? 'admin' : (rolePreference === 'admin' ? 'admin' : 'user');
    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = {
      _id: generateObjectId(),
      name: name.trim(),
      email: lowerEmail,
      password: hashedPassword,
      role: role,
      createdAt: new Date().toISOString()
    };

    database.users.push(newUser);
    saveDb();

    res.status(201).json({
      token: signToken(newUser),
      user: { id: newUser._id, name: newUser.name, email: newUser.email, role: newUser.role }
    });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

// POST /api/auth/login
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ message: 'Email and password required' });

    const user = database.users.find(u => u.email === (email || '').trim().toLowerCase());
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }

    res.json({
      token: signToken(user),
      user: { id: user._id, name: user.name, email: user.email, role: user.role }
    });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

// GET /api/auth/me
app.get('/api/auth/me', auth, (req, res) => {
  const user = database.users.find(u => u._id === req.user.id);
  if (!user) return res.status(404).json({ message: 'User not found' });
  res.json({ id: user._id, name: user.name, email: user.email, role: user.role });
});

// GET /api/categories
app.get('/api/categories', (req, res) => {
  res.json(CATEGORIES);
});

// GET /api/expenses (Query with filters: category, from, to, search, all)
app.get('/api/expenses', auth, (req, res) => {
  try {
    const isAdmin = req.user.role === 'admin';
    const showAll = isAdmin && req.query.all === 'true';

    let list = [...database.expenses];
    if (!showAll) {
      list = list.filter(e => e.user === req.user.id);
    }
    if (req.query.category && req.query.category !== 'All') {
      list = list.filter(e => e.category === req.query.category);
    }
    if (req.query.from) {
      list = list.filter(e => e.date >= req.query.from);
    }
    if (req.query.to) {
      list = list.filter(e => e.date <= req.query.to);
    }
    if (req.query.search) {
      const q = req.query.search.toLowerCase();
      list = list.filter(e => (e.description || '').toLowerCase().includes(q) || e.category.toLowerCase().includes(q));
    }

    // Sort by date descending
    list.sort((a, b) => b.date.localeCompare(a.date));

    // Populate User Details
    const usersMap = {};
    database.users.forEach(u => { usersMap[u._id] = { _id: u._id, name: u.name, email: u.email }; });

    const populated = list.map(e => ({
      ...e,
      user: usersMap[e.user] || null
    }));

    res.json(populated);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

// POST /api/expenses (CREATE)
app.post('/api/expenses', auth, (req, res) => {
  try {
    const err = validateExpense(req.body);
    if (err) return res.status(400).json({ message: err });

    const { date, category, amount, description } = req.body;
    const newRecord = {
      _id: generateObjectId(),
      user: req.user.id,
      date: date.slice(0, 10),
      category: category,
      amount: Number(amount),
      description: (description || '').trim(),
      createdAt: new Date().toISOString()
    };

    database.expenses.push(newRecord);
    saveDb();
    res.status(201).json(newRecord);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

// PUT /api/expenses/:id (UPDATE)
app.put('/api/expenses/:id', auth, (req, res) => {
  try {
    const err = validateExpense(req.body);
    if (err) return res.status(400).json({ message: err });

    const record = database.expenses.find(e => e._id === req.params.id);
    if (!record) return res.status(404).json({ message: 'Expense record not found' });

    if (record.user !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Forbidden: You can only edit your own expenses' });
    }

    const { date, category, amount, description } = req.body;
    record.date = date.slice(0, 10);
    record.category = category;
    record.amount = Number(amount);
    record.description = (description || '').trim();
    record.updatedAt = new Date().toISOString();

    saveDb();
    res.json(record);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

// DELETE /api/expenses/:id (DELETE)
app.delete('/api/expenses/:id', auth, (req, res) => {
  try {
    const idx = database.expenses.findIndex(e => e._id === req.params.id);
    if (idx === -1) return res.status(404).json({ message: 'Expense record not found' });

    const record = database.expenses[idx];
    if (record.user !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Forbidden: You can only delete your own expenses' });
    }

    database.expenses.splice(idx, 1);
    saveDb();
    res.json({ message: 'Expense deleted successfully', id: req.params.id });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

// GET /api/expenses/stats (Analytics Pipeline)
app.get('/api/expenses/stats', auth, (req, res) => {
  try {
    const isAdmin = req.user.role === 'admin';
    const showAll = isAdmin && req.query.all === 'true';

    let list = database.expenses;
    if (!showAll) {
      list = list.filter(e => e.user === req.user.id);
    }

    const curMonth = new Date().toISOString().slice(0, 7);
    let totalSpent = 0;
    let thisMonthSpent = 0;
    const catMap = {};
    const monthMap = {};

    list.forEach(e => {
      totalSpent += e.amount;
      if (e.date.startsWith(curMonth)) thisMonthSpent += e.amount;
      catMap[e.category] = (catMap[e.category] || 0) + e.amount;
      const m = e.date.slice(0, 7);
      monthMap[m] = (monthMap[m] || 0) + e.amount;
    });

    const categories = Object.entries(catMap)
      .map(([category, amount]) => ({
        category,
        amount,
        percentage: totalSpent > 0 ? (amount / totalSpent) * 100 : 0
      }))
      .sort((a, b) => b.amount - a.amount);

    res.json({
      totalSpent,
      thisMonthSpent,
      transactionCount: list.length,
      topCategory: categories[0] ? categories[0].category : 'N/A',
      categories,
      monthlyTotals: monthMap
    });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

// GET /api/admin/users (RBAC User Management)
app.get('/api/admin/users', auth, adminOnly, (req, res) => {
  try {
    const totals = {};
    database.expenses.forEach(e => {
      if (!totals[e.user]) totals[e.user] = { total: 0, count: 0 };
      totals[e.user].total += e.amount;
      totals[e.user].count += 1;
    });

    const userList = database.users.map(u => ({
      _id: u._id,
      name: u.name,
      email: u.email,
      role: u.role,
      createdAt: u.createdAt,
      totalSpent: (totals[u._id] || {}).total || 0,
      expenseCount: (totals[u._id] || {}).count || 0
    }));

    res.json(userList);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

// DELETE /api/admin/users/:id
app.delete('/api/admin/users/:id', auth, adminOnly, (req, res) => {
  try {
    if (req.params.id === req.user.id) {
      return res.status(400).json({ message: 'Administrators cannot delete their own account.' });
    }

    database.expenses = database.expenses.filter(e => e.user !== req.params.id);
    const uIdx = database.users.findIndex(u => u._id === req.params.id);
    if (uIdx !== -1) database.users.splice(uIdx, 1);
    saveDb();

    res.json({ message: 'User and all associated expenses deleted successfully.' });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

/* ============================================================
 *  4. SERVER INITIALIZATION
 * ============================================================
 */
if (require.main === module) {
  initSeedData().then(() => {
    app.listen(PORT, () => {
      console.log('========================================================');
      console.log(' Problem Statement 49: Expense Management (JavaScript)');
      console.log(' Developer & Presenter: Mantri Sreeja');
      console.log(' College: Malla Reddy Vishwavidyapeeth Technical Campus');
      console.log(` Server running on http://localhost:${PORT}`);
      console.log('========================================================');
    });
  });
} else {
  initSeedData();
}

module.exports = app;
