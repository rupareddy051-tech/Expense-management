import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import {
  CATEGORIES,
  Category,
  initDatabase,
  UserModel,
  ExpenseModel,
  getRawCollections,
  IUser,
} from './src/server/db.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'sreeja_mern_expense_secret_key_2026';

interface AuthPayload {
  id: string;
  role: 'user' | 'admin';
  name: string;
  email: string;
}

declare global {
  namespace Express {
    interface Request {
      user?: AuthPayload;
    }
  }
}

async function startServer() {
  await initDatabase();

  const app = express();
  app.use(cors());
  app.use(express.json());

  // Helper token signer
  const signToken = (u: IUser) =>
    jwt.sign(
      { id: u._id, role: u.role, name: u.name, email: u.email },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

  // Authentication Middleware
  const auth = (req: Request, res: Response, next: NextFunction): void => {
    const authHeader = req.headers.authorization || '';
    const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
    if (!token) {
      res.status(401).json({ message: 'Authentication required. Please login.' });
      return;
    }
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as AuthPayload;
      req.user = decoded;
      next();
    } catch {
      res.status(401).json({ message: 'Session expired or invalid token. Please log in again.' });
    }
  };

  // Admin-only Access Middleware
  const adminOnly = (req: Request, res: Response, next: NextFunction): void => {
    if (!req.user || req.user.role !== 'admin') {
      res.status(403).json({ message: 'Access denied. Admin privileges required.' });
      return;
    }
    next();
  };

  // Expense Validator
  const validateExpense = (b: any): string | null => {
    if (!b.date || isNaN(new Date(b.date).getTime())) {
      return 'Valid date in format YYYY-MM-DD is required';
    }
    if (!CATEGORIES.includes(b.category)) {
      return `Invalid category. Must be one of: ${CATEGORIES.join(', ')}`;
    }
    const amountNum = Number(b.amount);
    if (isNaN(amountNum) || amountNum <= 0) {
      return 'Amount must be a positive number greater than 0';
    }
    return null;
  };

  /* ====================== REST APIs ====================== */

  // 1. Auth: Register
  app.post('/api/auth/register', async (req: Request, res: Response) => {
    try {
      const { name, email, password, rolePreference } = req.body;
      if (!name || !email || !password) {
        res.status(400).json({ message: 'Name, email, and password are required' });
        return;
      }
      if (password.length < 6) {
        res.status(400).json({ message: 'Password must be at least 6 characters long' });
        return;
      }

      const existing = await UserModel.findByEmail(email);
      if (existing) {
        res.status(400).json({ message: 'Email already registered. Please log in instead.' });
        return;
      }

      const totalUsers = await UserModel.count();
      // First registered user is automatically admin, or user can request admin for demo testing
      const role: 'user' | 'admin' =
        totalUsers === 0 ? 'admin' : (rolePreference === 'admin' ? 'admin' : 'user');

      const hashedPassword = await bcrypt.hash(password, 10);
      const newUser = await UserModel.create({
        name,
        email,
        password: hashedPassword,
        role,
      });

      const token = signToken(newUser);
      res.status(201).json({
        token,
        user: {
          id: newUser._id,
          name: newUser.name,
          email: newUser.email,
          role: newUser.role,
        },
      });
    } catch (err: any) {
      res.status(500).json({ message: err.message || 'Internal server error during registration' });
    }
  });

  // 2. Auth: Login
  app.post('/api/auth/login', async (req: Request, res: Response) => {
    try {
      const { email, password } = req.body;
      if (!email || !password) {
        res.status(400).json({ message: 'Email and password are required' });
        return;
      }

      const user = await UserModel.findByEmail(email);
      if (!user) {
        res.status(400).json({ message: 'Invalid credentials. User not found.' });
        return;
      }

      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        res.status(400).json({ message: 'Invalid credentials. Incorrect password.' });
        return;
      }

      const token = signToken(user);
      res.json({
        token,
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
        },
      });
    } catch (err: any) {
      res.status(500).json({ message: err.message || 'Internal server error during login' });
    }
  });

  // 3. Auth: Current User
  app.get('/api/auth/me', auth, async (req: Request, res: Response) => {
    try {
      const user = await UserModel.findById(req.user!.id);
      if (!user) {
        res.status(404).json({ message: 'User not found' });
        return;
      }
      res.json({
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
      });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  // 4. Categories list
  app.get('/api/categories', (_req: Request, res: Response) => {
    res.json(CATEGORIES);
  });

  // 5. Expenses: READ (with filters)
  app.get('/api/expenses', auth, async (req: Request, res: Response) => {
    try {
      const isAdmin = req.user!.role === 'admin';
      const showAll = isAdmin && req.query.all === 'true';

      const filter: {
        user?: string;
        category?: string;
        from?: string;
        to?: string;
        search?: string;
      } = {};

      if (!showAll) {
        filter.user = req.user!.id;
      }

      if (req.query.category && typeof req.query.category === 'string') {
        filter.category = req.query.category;
      }

      if (req.query.from && typeof req.query.from === 'string') {
        filter.from = req.query.from;
      }

      if (req.query.to && typeof req.query.to === 'string') {
        filter.to = req.query.to;
      }

      if (req.query.search && typeof req.query.search === 'string') {
        filter.search = req.query.search;
      }

      const expenses = await ExpenseModel.find(filter);
      res.json(expenses);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  // 6. Expenses: CREATE
  app.post('/api/expenses', auth, async (req: Request, res: Response) => {
    try {
      const error = validateExpense(req.body);
      if (error) {
        res.status(400).json({ message: error });
        return;
      }

      const { date, category, amount, description } = req.body;
      const created = await ExpenseModel.create({
        user: req.user!.id,
        date: date.slice(0, 10),
        category: category as Category,
        amount: Number(amount),
        description: description || '',
      });

      res.status(201).json(created);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  // 7. Expenses: UPDATE
  app.put('/api/expenses/:id', auth, async (req: Request, res: Response) => {
    try {
      const error = validateExpense(req.body);
      if (error) {
        res.status(400).json({ message: error });
        return;
      }

      const existing = await ExpenseModel.findById(req.params.id);
      if (!existing) {
        res.status(404).json({ message: 'Expense record not found' });
        return;
      }

      // Check ownership or admin status
      if (existing.user !== req.user!.id && req.user!.role !== 'admin') {
        res.status(403).json({ message: 'Forbidden. You can only edit your own expenses.' });
        return;
      }

      const { date, category, amount, description } = req.body;
      const updated = await ExpenseModel.updateById(req.params.id, {
        date: date.slice(0, 10),
        category: category as Category,
        amount: Number(amount),
        description: description || '',
      });

      res.json(updated);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  // 8. Expenses: DELETE
  app.delete('/api/expenses/:id', auth, async (req: Request, res: Response) => {
    try {
      const existing = await ExpenseModel.findById(req.params.id);
      if (!existing) {
        res.status(404).json({ message: 'Expense record not found' });
        return;
      }

      if (existing.user !== req.user!.id && req.user!.role !== 'admin') {
        res.status(403).json({ message: 'Forbidden. You can only delete your own expenses.' });
        return;
      }

      await ExpenseModel.deleteById(req.params.id);
      res.json({ message: 'Expense deleted successfully', id: req.params.id });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  // 9. Expenses: Statistics & Analytics
  app.get('/api/expenses/stats', auth, async (req: Request, res: Response) => {
    try {
      const isAdmin = req.user!.role === 'admin';
      const showAll = isAdmin && req.query.all === 'true';
      const userId = showAll ? undefined : req.user!.id;

      const stats = await ExpenseModel.aggregateAnalytics(userId);
      res.json(stats);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  // 10. Admin: Users list with aggregates
  app.get('/api/admin/users', auth, adminOnly, async (_req: Request, res: Response) => {
    try {
      const users = await UserModel.find();
      const totalsMap = await ExpenseModel.aggregateUserTotals();

      const userList = users.map((u) => ({
        _id: u._id,
        name: u.name,
        email: u.email,
        role: u.role,
        createdAt: u.createdAt,
        totalSpent: totalsMap[u._id]?.total || 0,
        expenseCount: totalsMap[u._id]?.count || 0,
      }));

      res.json(userList);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  // 11. Admin: Delete User
  app.delete('/api/admin/users/:id', auth, adminOnly, async (req: Request, res: Response) => {
    try {
      const targetId = req.params.id;
      if (targetId === req.user!.id) {
        res.status(400).json({ message: 'Security restriction: Administrators cannot delete their own account.' });
        return;
      }

      const deletedExpensesCount = await ExpenseModel.deleteManyByUser(targetId);
      const userDeleted = await UserModel.deleteById(targetId);

      if (!userDeleted) {
        res.status(404).json({ message: 'User not found' });
        return;
      }

      res.json({
        message: 'User and all associated expense records deleted successfully',
        deletedExpensesCount,
      });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  // 12. Project Info & Academic Presentation Metadata
  app.get('/api/project-info', (_req: Request, res: Response) => {
    res.json({
      title: 'Expense Management System',
      problemStatementNumber: '49. Expense Management',
      description:
        'A full-stack MERN (MongoDB, Express.js, React.js, Node.js) application designed to systematically track, manage, and analyze personal and organizational expenditures with role-based security.',
      developer: {
        name: 'Mantri Sreeja',
        role: 'Developer & Presenter',
        institution: 'Malla Reddy Vishwavidyapeeth Technical Campus',
      },
      objectives: [
        'Demonstrate end-to-end MERN Stack software architecture.',
        'Implement full CRUD operations on MongoDB collections (User & Expense).',
        'Build structured RESTful APIs with Node.js and Express.js.',
        'Develop a high-performance, responsive UI using modern React.',
        'Implement token-based authentication (JWT) and Role-Based Access Control (RBAC).',
        'Present project metrics, visual budget breakdowns, and academic demo results clearly.',
      ],
      stack: {
        database: 'MongoDB (Mongoose Schemas with ObjectId refs, indexing & aggregations)',
        backend: 'Node.js runtime with Express.js REST APIs and JWT security middleware',
        frontend: 'React 19 SPA with Tailwind CSS and Lucide icons',
        security: 'BCrypt password hashing & JSON Web Token (JWT) bearer authentication',
      },
      restEndpoints: [
        { method: 'POST', path: '/api/auth/register', desc: 'Register new user / admin' },
        { method: 'POST', path: '/api/auth/login', desc: 'Authenticate user & issue JWT token' },
        { method: 'GET', path: '/api/auth/me', desc: 'Fetch currently authenticated session' },
        { method: 'GET', path: '/api/expenses', desc: 'Query expenses (supports filter, search & date range)' },
        { method: 'POST', path: '/api/expenses', desc: 'Create new expense record' },
        { method: 'PUT', path: '/api/expenses/:id', desc: 'Update existing expense (owner / admin only)' },
        { method: 'DELETE', path: '/api/expenses/:id', desc: 'Delete expense record (owner / admin only)' },
        { method: 'GET', path: '/api/expenses/stats', desc: 'Aggregate expenditure statistics & categories' },
        { method: 'GET', path: '/api/admin/users', desc: 'List all registered users & spending totals (admin only)' },
        { method: 'DELETE', path: '/api/admin/users/:id', desc: 'Delete user and cascade delete expenses' },
        { method: 'GET', path: '/api/categories', desc: 'Get supported expense categories list' },
        { method: 'GET', path: '/api/mongodb/inspect', desc: 'Live MongoDB schema and documents inspector' },
      ],
    });
  });

  // 13. Live MongoDB Inspection API (for demonstration/viva evaluation)
  app.get('/api/mongodb/inspect', (_req: Request, res: Response) => {
    res.json(getRawCollections());
  });

  // 14. Reset/Re-seed Demo Data API
  app.post('/api/mongodb/reset-seed', async (_req: Request, res: Response) => {
    await initDatabase(true);
    res.json({ message: 'Database successfully reset to default sample dataset.' });
  });

  // 15. Pure JavaScript Subjective Source Code API
  app.get('/api/source-code', (_req: Request, res: Response) => {
    try {
      const jsPath = path.resolve(__dirname, 'server.js');
      const code = fs.readFileSync(jsPath, 'utf8');
      res.json({
        filename: 'server.js',
        language: 'javascript',
        developer: 'Mantri Sreeja',
        college: 'Malla Reddy Vishwavidyapeeth Technical Campus',
        code,
      });
    } catch (err: any) {
      res.status(500).json({ message: 'Unable to read server.js: ' + err.message });
    }
  });

  // Frontend Serving Integration
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`=======================================================`);
    console.log(` 49. Expense Management System (MERN Stack)`);
    console.log(` Developer: Mantri Sreeja`);
    console.log(` College: Malla Reddy Vishwavidyapeeth Technical Campus`);
    console.log(` Server running on http://0.0.0.0:${PORT}`);
    console.log(`=======================================================`);
  });
}

startServer().catch((err) => {
  console.error('Fatal error starting server:', err);
  process.exit(1);
});
